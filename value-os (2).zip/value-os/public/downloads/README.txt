Put your Android app file here, named exactly:  value-os.apk

Once it is in this folder and the site redeploys, the "Download for Android"
buttons in the app and on /download.html appear automatically.
Generate the file with PWABuilder (pwabuilder.com) after the site is live.
