import React, { useState, useEffect, useCallback, useRef, useMemo } from "react";
import {
  Home as HomeIcon, Target, Sparkles, FolderKanban, User, MessageCircle,
  Lightbulb, BarChart3, Wallet, CalendarCheck, Settings as SettingsIcon,
  Crown, Plus, X, Check, Flame, ChevronRight, ChevronDown, Trash2, Send, Loader2,
  ArrowLeft, TrendingUp, TrendingDown, Download, AlertTriangle, Play, Pause,
  RotateCcw, Lock, Link2, Wand2, ClipboardList, BookOpen
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, LineChart, Line,
  CartesianGrid, Cell
} from "recharts";

/* ---------------------------------------------------------------------- */
/* DESIGN TOKENS                                                          */
/* ---------------------------------------------------------------------- */
const C = {
  bg: "#0A0C10", bgElevated: "#0F1218", surface: "#151A21", surfaceHi: "#1B212A",
  border: "#242B35", borderSoft: "#1C222B", text: "#EDEFF3", textDim: "#98A2B3", textFaint: "#5B6472",
  accent: "#4ADE9E", accentDim: "#2E8A63", accentSoft: "rgba(74,222,158,0.12)",
  amber: "#E8B24D", amberSoft: "rgba(232,178,77,0.12)",
  rose: "#F0708A", roseSoft: "rgba(240,112,138,0.12)",
  blue: "#5DA9E9", blueSoft: "rgba(93,169,233,0.12)",
  violet: "#B98CE0", violetSoft: "rgba(185,140,224,0.12)",
  teal: "#4FD1C5", tealSoft: "rgba(79,209,197,0.12)",
  indigo: "#8B9CF7", indigoSoft: "rgba(139,156,247,0.12)",
};

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap');
* { font-family: 'Inter', -apple-system, sans-serif; box-sizing: border-box; }
.font-display { font-family: 'Space Grotesk', 'Inter', sans-serif; }
::-webkit-scrollbar { width: 0px; height: 0px; }
input, textarea, select { font-family: 'Inter', sans-serif; }
@keyframes riseIn { from { opacity:0; transform: translateY(6px);} to { opacity:1; transform:translateY(0);} }
.rise { animation: riseIn .28s ease-out; }
@keyframes spin { to { transform: rotate(360deg); } }
@media (prefers-reduced-motion: reduce) { .rise { animation: none; } }
`;

/* ---------------------------------------------------------------------- */
/* MODEL / TAXONOMIES                                                     */
/* ---------------------------------------------------------------------- */
// Business-pillar model (used for Opportunity Lab + project vocabulary)
const PILLARS = [
  { id: "learn", label: "Learn", color: C.blue },
  { id: "build", label: "Build", color: C.accent },
  { id: "solve", label: "Solve", color: C.amber },
  { id: "sell", label: "Sell", color: C.rose },
  { id: "reinvest", label: "Reinvest", color: C.violet },
  { id: "scale", label: "Scale", color: C.teal },
];
const pillarOf = (id) => PILLARS.find((p) => p.id === id) || PILLARS[0];

// Mission / Value Score categories — weighted per the Value Score Engine.
// Building and Problem Solving are weighted highest on purpose: producing
// something real is worth more than passively consuming information.
const CATEGORIES = [
  { id: "learning", label: "Learning", color: C.blue, points: 10 },
  { id: "skill_practice", label: "Skill Practice", color: C.teal, points: 15 },
  { id: "building", label: "Building", color: C.accent, points: 20 },
  { id: "problem_solving", label: "Problem Solving", color: C.amber, points: 20 },
  { id: "execution", label: "Execution", color: C.violet, points: 15 },
  { id: "comm_sales", label: "Communication/Sales", color: C.rose, points: 10 },
  { id: "health", label: "Health/Discipline", color: C.indigo, points: 10 },
];
const categoryOf = (id) => CATEGORIES.find((c) => c.id === id) || CATEGORIES[0];
const MAX_DAILY_SCORE = CATEGORIES.reduce((s, c) => s + c.points, 0); // 100

const DIFFICULTIES = [
  { id: "easy", label: "Easy", xp: 10 },
  { id: "medium", label: "Medium", xp: 25 },
  { id: "hard", label: "Hard", xp: 50 },
];
const diffXp = (id) => (DIFFICULTIES.find((d) => d.id === id) || DIFFICULTIES[0]).xp;

// Skill tree
const SKILL_GROUPS = [
  { id: "technology", label: "Technology", color: C.blue, subs: ["Programming", "AI", "Automation", "Web Development", "App Development", "Data", "Cybersecurity Fundamentals"] },
  { id: "business", label: "Business", color: C.amber, subs: ["Market Research", "Sales", "Marketing", "Negotiation", "Product Development", "Business Strategy"] },
  { id: "money", label: "Money", color: C.teal, subs: ["Personal Finance", "Budgeting", "Investing Fundamentals", "Risk Management", "Economics"] },
  { id: "communication", label: "Communication", color: C.rose, subs: ["Writing", "Speaking", "Presentation", "Networking"] },
  { id: "performance", label: "Personal Performance", color: C.violet, subs: ["Focus", "Discipline", "Time Management", "Decision Making"] },
];
const groupOf = (id) => SKILL_GROUPS.find((g) => g.id === id) || SKILL_GROUPS[0];

const PROJECT_STAGES = ["Idea", "Problem", "Validation", "MVP", "Launch", "Feedback", "Iteration", "Revenue", "Scale"];
const STAGE_PALETTE = [C.textDim, C.rose, C.amber, C.blue, C.violet, C.indigo, C.teal, C.accent, "#FFD36E"];
const stageColor = (stage) => STAGE_PALETTE[PROJECT_STAGES.indexOf(stage)] || C.textDim;
const PROJECT_STATUSES = ["Active", "Paused", "Completed", "Abandoned"];

// Onboarding option sets
const GOALS = [
  "Become financially independent", "Build a startup", "Become a developer", "Become a freelancer",
  "Build digital products", "Grow a content business", "Improve academic performance", "Develop high-income skills",
];
const AGE_RANGES = ["Under 18", "18–24", "25–34", "35–44", "45+"];
const SKILL_LEVELS = ["Beginner", "Intermediate", "Advanced"];
const DAILY_TIME = ["Under 30 min", "30–60 min", "1–2 hrs", "2–4 hrs", "4+ hrs"];
const LEARNING_STYLES = ["Reading", "Video", "Hands-on / Projects", "Mentorship / Discussion"];
const BUSINESS_INTERESTS = ["Software / SaaS", "E-commerce", "Content Creation", "Freelance Services", "Consulting", "Education", "Digital Products", "Local Business", "Not sure yet"];

const todayStr = () => new Date().toISOString().slice(0, 10);
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
const fmtDate = (d) => new Date(d + "T00:00:00").toLocaleDateString(undefined, { month: "short", day: "numeric" });
const levelFromXp = (xp) => Math.floor(xp / 100) + 1;
const xpIntoLevel = (xp) => xp % 100;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const mmss = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;

const seedProfile = () => ({
  name: "Builder", xp: 0, streak: 0, lastActiveDate: null, missionsCompleted: 0,
  createdAt: todayStr(), onboarded: false, scoreHistory: [],
  ageRange: "", role: "", mainGoal: "", longTermVision: "", skillLevel: "",
  dailyTime: "", existingSkills: "", interests: "", learningStyle: "",
  businessInterests: [], currentProjectsText: "", biggestObstacle: "",
  roadmap: null, achievementsUnlocked: {}, checkins: [],
});

// Achievements — meaningful, not gamification for its own sake.
const ACHIEVEMENTS = [
  { id: "first_mission", label: "First Mission", description: "Complete your first mission.", icon: Target, check: (s) => s.profile.missionsCompleted >= 1 },
  { id: "first_build", label: "First Build", description: "Finish your first project milestone.", icon: FolderKanban, check: (s) => s.projects.some((p) => (p.tasks || []).some((t) => t.done)) },
  { id: "seven_day_execution", label: "7-Day Execution", description: "Complete meaningful work 7 days in a row.", icon: Flame, check: (s) => s.profile.streak >= 7 },
  { id: "first_validation", label: "First Validation", description: "Validate your first business idea.", icon: ClipboardList, check: (s) => s.projects.some((p) => PROJECT_STAGES.indexOf(p.stage) >= PROJECT_STAGES.indexOf("Validation")) },
  { id: "first_revenue", label: "First Revenue", description: "Record your first legitimate revenue.", icon: TrendingUp, check: (s) => s.projects.some((p) => Number(p.revenue) > 0) || s.finance.some((f) => f.type === "income" && Number(f.amount) > 0) },
  { id: "skill_builder", label: "Skill Builder", description: "Reach Level 5 in a skill.", icon: Sparkles, check: (s) => s.skills.some((sk) => levelFromXp(sk.xp) >= 5) },
];

/* ---------------------------------------------------------------------- */
/* STORAGE HELPERS                                                        */
/* ---------------------------------------------------------------------- */
async function loadKey(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) { return fallback; }
}
async function saveKey(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* silent */ }
}

/* ---------------------------------------------------------------------- */
/* AI CALL HELPER                                                         */
/* ---------------------------------------------------------------------- */
async function askClaude(system, messages) {
  // Calls our own serverless function (api/mentor.js) so the Anthropic API key
  // stays on the server and is never exposed in the browser.
  const res = await fetch("/api/mentor", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system, messages }),
  });
  if (!res.ok) throw new Error("mentor request failed");
  const data = await res.json();
  return data.text || "";
}
function parseJsonLoose(raw, fallback) {
  try { return JSON.parse(raw.replace(/```json|```/g, "").trim()); } catch (e) { return fallback; }
}

/* ---------------------------------------------------------------------- */
/* SHARED UI                                                              */
/* ---------------------------------------------------------------------- */
function Card({ children, style, className = "", onClick }) {
  return (
    <div onClick={onClick} className={`rise ${className}`}
      style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 18, padding: 16, ...style }}>
      {children}
    </div>
  );
}

function Button({ children, onClick, variant = "primary", style, disabled, type = "button", full }) {
  const base = {
    display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8,
    fontWeight: 600, fontSize: 14, padding: "11px 18px", borderRadius: 12,
    border: "1px solid transparent", cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1, transition: "transform .12s ease, opacity .12s ease",
    width: full ? "100%" : "auto",
  };
  const variants = {
    primary: { background: C.accent, color: "#06120C" },
    secondary: { background: C.surfaceHi, color: C.text, borderColor: C.border },
    ghost: { background: "transparent", color: C.textDim, borderColor: "transparent" },
    danger: { background: C.roseSoft, color: C.rose, borderColor: "rgba(240,112,138,0.3)" },
  };
  return (
    <button type={type} disabled={disabled} onClick={onClick}
      onPointerDown={(e) => { if (!disabled) e.currentTarget.style.transform = "scale(0.97)"; }}
      onPointerUp={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      onPointerLeave={(e) => { e.currentTarget.style.transform = "scale(1)"; }}
      style={{ ...base, ...variants[variant], ...style }}>
      {children}
    </button>
  );
}

function ProgressBar({ value, color = C.accent, track = C.surfaceHi, height = 8 }) {
  return (
    <div style={{ width: "100%", height, borderRadius: 999, background: track, overflow: "hidden" }}>
      <div style={{ width: `${clamp(value, 0, 100)}%`, height: "100%", background: color, borderRadius: 999, transition: "width .3s ease" }} />
    </div>
  );
}

function Tag({ label, color, size = "sm" }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 6, fontSize: size === "sm" ? 11 : 12, fontWeight: 600,
      color, background: `${color}1F`, padding: size === "sm" ? "4px 9px" : "5px 11px", borderRadius: 999,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: color }} />
      {label}
    </span>
  );
}

function Header({ title, onBack, right }) {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "18px 20px 6px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        {onBack && (
          <button onClick={onBack} style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", color: C.text }}>
            <ArrowLeft size={17} />
          </button>
        )}
        <h1 className="font-display" style={{ fontSize: 20, fontWeight: 700, color: C.text, margin: 0 }}>{title}</h1>
      </div>
      {right}
    </div>
  );
}

function EmptyState({ icon: Icon, title, sub, action }) {
  return (
    <div className="rise" style={{ textAlign: "center", padding: "40px 24px", color: C.textDim }}>
      <div style={{ width: 52, height: 52, borderRadius: 16, background: C.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 14px" }}>
        <Icon size={22} color={C.textFaint} />
      </div>
      <div style={{ color: C.text, fontWeight: 600, fontSize: 15, marginBottom: 4 }}>{title}</div>
      <div style={{ fontSize: 13, lineHeight: 1.5, maxWidth: 260, margin: "0 auto" }}>{sub}</div>
      {action && <div style={{ marginTop: 16 }}>{action}</div>}
    </div>
  );
}

function Modal({ title, onClose, children, footer }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(5,7,10,0.7)", backdropFilter: "blur(3px)", display: "flex", alignItems: "flex-end", justifyContent: "center", zIndex: 100 }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className="rise"
        style={{ background: C.bgElevated, border: `1px solid ${C.border}`, borderBottom: "none", borderRadius: "22px 22px 0 0", width: "100%", maxWidth: 480, maxHeight: "85vh", overflowY: "auto", padding: "18px 20px 24px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
          <h2 className="font-display" style={{ fontSize: 17, fontWeight: 700, color: C.text, margin: 0 }}>{title}</h2>
          <button onClick={onClose} style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 999, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", color: C.textDim }}>
            <X size={15} />
          </button>
        </div>
        {children}
        {footer && <div style={{ marginTop: 18 }}>{footer}</div>}
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <label style={{ display: "block", fontSize: 12.5, fontWeight: 600, color: C.textDim, marginBottom: 7 }}>{label}</label>
      {children}
    </div>
  );
}

const inputStyle = { width: "100%", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 11, padding: "11px 13px", color: C.text, fontSize: 14, outline: "none" };

function SegPicker({ options, value, onChange, getLabel = (o) => o, getKey = (o) => o }) {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
      {options.map((opt) => {
        const key = getKey(opt); const active = key === value;
        return (
          <button key={key} type="button" onClick={() => onChange(key)} style={{
            padding: "8px 13px", borderRadius: 10, fontSize: 13, fontWeight: 600, cursor: "pointer",
            background: active ? C.accentSoft : C.surface, color: active ? C.accent : C.textDim,
            border: `1px solid ${active ? "rgba(74,222,158,0.4)" : C.border}`,
          }}>{getLabel(opt)}</button>
        );
      })}
    </div>
  );
}

function MultiChipPicker({ options, values, onToggle }) {
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
      {options.map((opt) => {
        const active = values.includes(opt);
        return (
          <button key={opt} type="button" onClick={() => onToggle(opt)} style={{
            padding: "8px 13px", borderRadius: 10, fontSize: 12.5, fontWeight: 600, cursor: "pointer",
            background: active ? C.accentSoft : C.surface, color: active ? C.accent : C.textDim,
            border: `1px solid ${active ? "rgba(74,222,158,0.4)" : C.border}`,
          }}>{active ? "✓ " : ""}{opt}</button>
        );
      })}
    </div>
  );
}

function StatBox({ label, value, icon: Icon, color = C.accent }) {
  return (
    <Card style={{ padding: 14, flex: 1, minWidth: 0 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
        <Icon size={14} color={color} />
        <span style={{ fontSize: 11, color: C.textDim, fontWeight: 600 }}>{label}</span>
      </div>
      <div className="font-display" style={{ fontSize: 20, fontWeight: 700, color: C.text }}>{value}</div>
    </Card>
  );
}

/* ---------------------------------------------------------------------- */
/* VALUE SCORE                                                            */
/* ---------------------------------------------------------------------- */
// Points are weighted per category (Building/Problem Solving score highest —
// passive learning alone can't max the score). xpToday is driven by actual
// completed missions (difficulty-based XP), never by time spent, so
// watching videos never auto-equals productive work.
function scoreForDate(missions, date) {
  let total = 0;
  CATEGORIES.forEach((cat) => {
    const xpToday = missions.filter((m) => m.done && m.date === date && m.category === cat.id).reduce((s, m) => s + diffXp(m.difficulty), 0);
    total += Math.min(cat.points, (xpToday / 30) * cat.points);
  });
  return Math.round(clamp(total, 0, MAX_DAILY_SCORE));
}

/* ---------------------------------------------------------------------- */
/* MISSION ROW (shared: Home directive + Missions list)                   */
/* ---------------------------------------------------------------------- */
function MissionRow({ mission, numberLabel, onComplete, onUncomplete, onDelete, timer, onTimerToggle, onTimerReset }) {
  const cat = categoryOf(mission.category);
  const dxp = diffXp(mission.difficulty);
  const est = mission.estimatedMinutes || 0;
  const totalSec = est * 60;
  const remaining = timer ? timer.remaining : totalSec;
  const running = timer ? timer.running : false;

  if (mission.done) {
    return (
      <Card style={{ padding: 13, display: "flex", alignItems: "center", gap: 12, opacity: 0.55 }}>
        <button onClick={() => onUncomplete(mission.id)} style={{ width: 24, height: 24, borderRadius: 999, border: `2px solid ${cat.color}`, background: cat.color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, cursor: "pointer" }}>
          <Check size={13} color="#06120C" />
        </button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, textDecoration: "line-through" }}>{mission.title}</div>
        </div>
        {onDelete && <button onClick={() => onDelete(mission.id)} style={{ background: "none", border: "none", color: C.textFaint, cursor: "pointer" }}><Trash2 size={15} /></button>}
      </Card>
    );
  }

  return (
    <Card style={{ padding: 14 }}>
      <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
        <button onClick={() => onComplete(mission.id)} style={{ width: 24, height: 24, marginTop: 1, borderRadius: 999, border: `2px solid ${cat.color}`, background: "transparent", flexShrink: 0, cursor: "pointer" }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          {numberLabel && <div className="font-display" style={{ fontSize: 10.5, fontWeight: 700, color: C.textFaint, letterSpacing: 0.5, marginBottom: 3 }}>{numberLabel}</div>}
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>{mission.title}</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
            <Tag label={cat.label} color={cat.color} />
            <span style={{ fontSize: 11, color: C.textFaint }}>{mission.difficulty} · +{dxp}xp</span>
            {est > 0 && <span style={{ fontSize: 11, color: C.textFaint }}>· {est} min</span>}
          </div>
          {mission.reason && <div style={{ fontSize: 11.5, color: C.textDim, marginTop: 6, lineHeight: 1.5 }}>{mission.reason}</div>}
        </div>
        {onDelete && <button onClick={() => onDelete(mission.id)} style={{ background: "none", border: "none", color: C.textFaint, cursor: "pointer" }}><Trash2 size={15} /></button>}
      </div>
      {est > 0 && onTimerToggle && (
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 12, paddingTop: 12, borderTop: `1px solid ${C.borderSoft}` }}>
          <span className="font-display" style={{ fontSize: 15, fontWeight: 700, color: running ? C.accent : C.text, minWidth: 52 }}>{mmss(remaining)}</span>
          <ProgressBar value={totalSec ? ((totalSec - remaining) / totalSec) * 100 : 0} color={cat.color} />
          <button onClick={() => onTimerToggle(mission.id, totalSec)} style={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 9, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            {running ? <Pause size={13} color={C.text} /> : <Play size={13} color={C.text} />}
          </button>
          <button onClick={() => onTimerReset(mission.id, totalSec)} style={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 9, width: 30, height: 30, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <RotateCcw size={12} color={C.textDim} />
          </button>
        </div>
      )}
    </Card>
  );
}

/* ---------------------------------------------------------------------- */
/* ONBOARDING                                                             */
/* ---------------------------------------------------------------------- */
function Onboarding({ onComplete }) {
  const [step, setStep] = useState(0);
  const [busy, setBusy] = useState(false);
  const [roadmap, setRoadmap] = useState(null);
  const [error, setError] = useState(null);
  const [a, setA] = useState({
    name: "", ageRange: "", role: "", mainGoal: "", longTermVision: "", skillLevel: "",
    dailyTime: "", existingSkills: "", interests: "", learningStyle: "",
    businessInterests: [], currentProjectsText: "", biggestObstacle: "",
  });
  const set = (k, v) => setA((s) => ({ ...s, [k]: v }));
  const toggleBiz = (v) => setA((s) => ({ ...s, businessInterests: s.businessInterests.includes(v) ? s.businessInterests.filter((x) => x !== v) : [...s.businessInterests, v] }));

  const steps = [
    { key: "name", title: "What should we call you?", body: <input style={inputStyle} autoFocus value={a.name} onChange={(e) => set("name", e.target.value)} placeholder="Your name" />, valid: a.name.trim().length > 0 },
    { key: "ageRange", title: "What's your age range?", body: <SegPicker options={AGE_RANGES} value={a.ageRange} onChange={(v) => set("ageRange", v)} />, valid: !!a.ageRange },
    { key: "role", title: "What's your current role?", body: <input style={inputStyle} value={a.role} onChange={(e) => set("role", e.target.value)} placeholder="Student, freelancer, employee…" />, valid: a.role.trim().length > 0 },
    { key: "mainGoal", title: "What's your main goal right now?", body: <SegPicker options={GOALS} value={a.mainGoal} onChange={(v) => set("mainGoal", v)} />, valid: !!a.mainGoal },
    { key: "longTermVision", title: "Describe your long-term vision", sub: "A sentence or two on where you want to be in a few years.", body: <textarea style={{ ...inputStyle, minHeight: 90 }} value={a.longTermVision} onChange={(e) => set("longTermVision", e.target.value)} />, valid: a.longTermVision.trim().length > 0 },
    { key: "skillLevel", title: "How would you rate your current skill level?", body: <SegPicker options={SKILL_LEVELS} value={a.skillLevel} onChange={(v) => set("skillLevel", v)} />, valid: !!a.skillLevel },
    { key: "dailyTime", title: "How much time can you invest daily?", body: <SegPicker options={DAILY_TIME} value={a.dailyTime} onChange={(v) => set("dailyTime", v)} />, valid: !!a.dailyTime },
    { key: "existingSkills", title: "What skills do you already have?", sub: "Separate with commas.", body: <textarea style={{ ...inputStyle, minHeight: 70 }} value={a.existingSkills} onChange={(e) => set("existingSkills", e.target.value)} placeholder="e.g. writing, spreadsheets, basic design" />, valid: true },
    { key: "interests", title: "What are you interested in?", sub: "Topics, industries, or problems you care about.", body: <textarea style={{ ...inputStyle, minHeight: 70 }} value={a.interests} onChange={(e) => set("interests", e.target.value)} />, valid: true },
    { key: "learningStyle", title: "How do you prefer to learn?", body: <SegPicker options={LEARNING_STYLES} value={a.learningStyle} onChange={(v) => set("learningStyle", v)} />, valid: !!a.learningStyle },
    { key: "businessInterests", title: "Any business interests?", sub: "Pick as many as apply.", body: <MultiChipPicker options={BUSINESS_INTERESTS} values={a.businessInterests} onToggle={toggleBiz} />, valid: true },
    { key: "currentProjectsText", title: "Are you working on anything already?", sub: "Optional — describe any current projects.", body: <textarea style={{ ...inputStyle, minHeight: 70 }} value={a.currentProjectsText} onChange={(e) => set("currentProjectsText", e.target.value)} />, valid: true },
    { key: "biggestObstacle", title: "What's the biggest thing holding you back?", body: <textarea style={{ ...inputStyle, minHeight: 70 }} value={a.biggestObstacle} onChange={(e) => set("biggestObstacle", e.target.value)} />, valid: a.biggestObstacle.trim().length > 0 },
  ];

  const generate = async () => {
    setBusy(true); setError(null);
    const system = `You are the roadmap engine inside VALUE OS, an app that helps people build real skills and value through Learn -> Build -> Solve -> Sell -> Reinvest -> Scale. Never promise guaranteed income or "get rich quick" outcomes; be direct, realistic, and encouraging. Respond ONLY with raw JSON (no markdown fences), an object with keys:
"twelveMonth" (string, a realistic 12-month direction),
"ninetyDay" (string, a concrete 90-day objective),
"currentPriority" (string, the single most important thing to focus on right now),
"recommendedSkills" (array of up to 4 objects: {"name": string, "group": one of technology|business|money|communication|performance, "subcategory": string}),
"recommendedProjects" (array of up to 2 objects: {"name": string, "description": string}),
"dailyActions" (array of 3-4 short, concrete action strings for a starter daily routine, each an ACTION not passive content like "read a quote").`;
    const user = `Name: ${a.name}\nAge range: ${a.ageRange}\nRole: ${a.role}\nMain goal: ${a.mainGoal}\nLong-term vision: ${a.longTermVision}\nSkill level: ${a.skillLevel}\nDaily time available: ${a.dailyTime}\nExisting skills: ${a.existingSkills || "none listed"}\nInterests: ${a.interests || "none listed"}\nLearning style: ${a.learningStyle}\nBusiness interests: ${a.businessInterests.join(", ") || "none"}\nCurrent projects: ${a.currentProjectsText || "none"}\nBiggest obstacle: ${a.biggestObstacle}`;
    try {
      const raw = await askClaude(system, [{ role: "user", content: user }]);
      const parsed = parseJsonLoose(raw, null);
      setRoadmap(parsed);
    } catch (e) {
      setError("Couldn't generate your roadmap — you can still continue and generate one later from the Mentor.");
    } finally { setBusy(false); }
  };

  useEffect(() => { if (step === steps.length) generate(); /* eslint-disable-next-line */ }, [step]);

  if (step === steps.length) {
    return (
      <div style={{ minHeight: "100vh", background: C.bg, color: C.text, maxWidth: 480, margin: "0 auto", padding: "60px 24px" }}>
        <style>{FONTS}</style>
        {busy && (
          <div style={{ textAlign: "center", marginTop: 100 }}>
            <Loader2 size={26} color={C.accent} style={{ animation: "spin 1s linear infinite" }} />
            <div style={{ marginTop: 16, fontSize: 14, color: C.textDim }}>Building your Value Roadmap…</div>
          </div>
        )}
        {!busy && (
          <div className="rise">
            <div style={{ fontSize: 12, fontWeight: 700, color: C.accent, letterSpacing: 0.5, marginBottom: 8 }}>YOUR VALUE ROADMAP</div>
            <h1 className="font-display" style={{ fontSize: 24, fontWeight: 700, margin: "0 0 20px" }}>Welcome, {a.name}.</h1>
            {error && <div style={{ fontSize: 13, color: C.amber, marginBottom: 16 }}>{error}</div>}
            {roadmap ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <Card><div style={{ fontSize: 11.5, fontWeight: 700, color: C.textFaint, marginBottom: 6 }}>12-MONTH DIRECTION</div><div style={{ fontSize: 14, lineHeight: 1.55 }}>{roadmap.twelveMonth}</div></Card>
                <Card><div style={{ fontSize: 11.5, fontWeight: 700, color: C.textFaint, marginBottom: 6 }}>90-DAY OBJECTIVE</div><div style={{ fontSize: 14, lineHeight: 1.55 }}>{roadmap.ninetyDay}</div></Card>
                <Card style={{ borderColor: "rgba(74,222,158,0.35)" }}><div style={{ fontSize: 11.5, fontWeight: 700, color: C.accent, marginBottom: 6 }}>CURRENT PRIORITY</div><div style={{ fontSize: 14, lineHeight: 1.55, fontWeight: 600 }}>{roadmap.currentPriority}</div></Card>
                {roadmap.recommendedSkills?.length > 0 && (
                  <Card>
                    <div style={{ fontSize: 11.5, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>RECOMMENDED SKILLS</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{roadmap.recommendedSkills.map((s, i) => <Tag key={i} label={s.name} color={groupOf(s.group).color} />)}</div>
                  </Card>
                )}
                {roadmap.recommendedProjects?.length > 0 && (
                  <Card>
                    <div style={{ fontSize: 11.5, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>RECOMMENDED PROJECTS</div>
                    {roadmap.recommendedProjects.map((p, i) => <div key={i} style={{ fontSize: 13, marginBottom: 6 }}><strong>{p.name}</strong> — <span style={{ color: C.textDim }}>{p.description}</span></div>)}
                  </Card>
                )}
                {roadmap.dailyActions?.length > 0 && (
                  <Card>
                    <div style={{ fontSize: 11.5, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>STARTER DAILY ACTIONS</div>
                    {roadmap.dailyActions.map((d, i) => <div key={i} style={{ fontSize: 13, marginBottom: 6, color: C.text }}>• {d}</div>)}
                  </Card>
                )}
              </div>
            ) : (
              <Card><div style={{ fontSize: 13, color: C.textDim }}>No roadmap generated yet — you'll start with a blank slate and can ask your AI Mentor for direction anytime.</div></Card>
            )}
            <Button full style={{ marginTop: 22 }} onClick={() => onComplete(a, roadmap)}>Enter Value OS</Button>
          </div>
        )}
      </div>
    );
  }

  const s = steps[step];
  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, maxWidth: 480, margin: "0 auto", display: "flex", flexDirection: "column" }}>
      <style>{FONTS}</style>
      <div style={{ padding: "24px 24px 0" }}>
        <div style={{ display: "flex", gap: 4, marginBottom: 28 }}>
          {steps.map((_, i) => <div key={i} style={{ flex: 1, height: 3, borderRadius: 2, background: i <= step ? C.accent : C.borderSoft }} />)}
        </div>
        <div style={{ fontSize: 11, fontWeight: 700, color: C.textFaint, letterSpacing: 0.5, marginBottom: 8 }}>STEP {step + 1} OF {steps.length}</div>
        <h1 className="font-display rise" key={s.key} style={{ fontSize: 21, fontWeight: 700, margin: "0 0 6px", lineHeight: 1.3 }}>{s.title}</h1>
        {s.sub && <div style={{ fontSize: 13, color: C.textDim, marginBottom: 18 }}>{s.sub}</div>}
        <div style={{ marginTop: s.sub ? 0 : 18 }}>{s.body}</div>
      </div>
      <div style={{ marginTop: "auto", padding: "18px 24px 28px", display: "flex", gap: 10 }}>
        {step > 0 && <Button variant="secondary" onClick={() => setStep((v) => v - 1)}>Back</Button>}
        <Button full disabled={!s.valid} onClick={() => setStep((v) => v + 1)}>{step === steps.length - 1 ? "Generate roadmap" : "Continue"}</Button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* GET THE APP (install / download)                                        */
/* ---------------------------------------------------------------------- */
function isStandaloneMode() {
  if (typeof window === "undefined") return false;
  return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) || window.navigator.standalone === true;
}

// The browser's install event is captured early in index.html (it can fire
// before React mounts) and handed to us through window.__vosInstall.
function useInstall() {
  const [evt, setEvt] = useState(() => (typeof window !== "undefined" ? window.__vosInstall || null : null));
  const [installed, setInstalled] = useState(isStandaloneMode);
  useEffect(() => {
    const onReady = () => setEvt(window.__vosInstall || null);
    const onInstalled = () => { setEvt(null); setInstalled(true); };
    window.addEventListener("vos-install-ready", onReady);
    window.addEventListener("vos-installed", onInstalled);
    return () => {
      window.removeEventListener("vos-install-ready", onReady);
      window.removeEventListener("vos-installed", onInstalled);
    };
  }, []);
  const ua = typeof navigator !== "undefined" ? navigator.userAgent || "" : "";
  const isIOS = /iphone|ipad|ipod/i.test(ua) || (typeof navigator !== "undefined" && navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const promptInstall = async () => {
    if (!evt) return;
    evt.prompt();
    try { await evt.userChoice; } catch (e) { /* dismissed */ }
    window.__vosInstall = null;
    setEvt(null);
  };
  return { canInstall: !!evt && !installed, isIOS, installed, promptInstall };
}

// Shows the APK button only if the file has actually been uploaded. A missing
// file falls through to index.html, so we check it isn't an HTML response.
function useApkAvailable() {
  const [available, setAvailable] = useState(false);
  useEffect(() => {
    let cancelled = false;
    fetch("/downloads/value-os.apk", { method: "HEAD" })
      .then((r) => {
        const type = r.headers.get("content-type") || "";
        if (!cancelled) setAvailable(r.ok && !type.includes("text/html"));
      })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);
  return { apkUrl: "/downloads/value-os.apk", apkAvailable: available };
}

function GetAppCard() {
  const { canInstall, isIOS, installed, promptInstall } = useInstall();
  const { apkUrl, apkAvailable } = useApkAvailable();
  const [msg, setMsg] = useState(null);
  const shareUrl = typeof window !== "undefined" ? `${window.location.origin}/download.html` : "/download.html";

  const share = async () => {
    try {
      if (navigator.share) {
        await navigator.share({ title: "Value OS", text: "Build skills. Create value. Get the Value OS app:", url: shareUrl });
        return;
      }
      await navigator.clipboard.writeText(shareUrl);
      setMsg("Download link copied");
      setTimeout(() => setMsg(null), 2200);
    } catch (e) { /* share sheet dismissed */ }
  };

  return (
    <Card>
      <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>Get the app</div>
      {installed ? (
        <div style={{ fontSize: 12.5, color: C.accent, marginBottom: 12, lineHeight: 1.5 }}>Value OS is installed on this device.</div>
      ) : (
        <div style={{ fontSize: 12.5, color: C.textDim, marginBottom: 12, lineHeight: 1.5 }}>
          {canInstall
            ? "Add Value OS to your home screen. It opens full screen and keeps working offline."
            : isIOS
              ? "On iPhone or iPad: tap Share in Safari, then Add to Home Screen."
              : "In Chrome, open the ⋮ menu and tap Install app."}
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {canInstall && <Button full onClick={promptInstall}><Download size={14} /> Install app</Button>}
        {apkAvailable && !isIOS && (
          <a href={apkUrl} download="value-os.apk" style={{
            display: "flex", alignItems: "center", justifyContent: "center", gap: 8, width: "100%",
            fontWeight: 600, fontSize: 14, padding: "11px 18px", borderRadius: 12, textDecoration: "none",
            background: canInstall ? C.surfaceHi : C.accent, color: canInstall ? C.text : "#06120C",
            border: `1px solid ${canInstall ? C.border : "transparent"}`,
          }}><Download size={14} /> Download for Android (.apk)</a>
        )}
        <Button full variant="secondary" onClick={share}>{msg || "Share download link"}</Button>
      </div>
    </Card>
  );
}

/* ---------------------------------------------------------------------- */
/* AUTH                                                                    */
/* ---------------------------------------------------------------------- */
function AuthView({ onAuthed }) {
  const [mode, setMode] = useState("login"); // login | signup | reset
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [resetSent, setResetSent] = useState(false);

  const submit = async () => {
    setError(null);
    if (mode !== "reset" && (!email.trim() || !password)) { setError("Email and password are required."); return; }
    setBusy(true);
    try {
      if (mode === "reset") {
        const res = await fetch("/api/auth/request-password-reset", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: email.trim() }) });
        if (res.ok) setResetSent(true); else setError("Something went wrong. Try again.");
      } else {
        const path = mode === "signup" ? "/api/auth/signup" : "/api/auth/login";
        const res = await fetch(path, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: email.trim(), password, name: name.trim() || undefined }) });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) { setError(data.error || "Something went wrong."); return; }
        await onAuthed();
      }
    } catch (e) {
      setError("Couldn't reach the server. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, maxWidth: 480, margin: "0 auto", display: "flex", flexDirection: "column", justifyContent: "center", padding: 28 }}>
      <style>{FONTS}</style>
      <div style={{ marginBottom: 28 }}>
        <div className="font-display" style={{ fontSize: 26, fontWeight: 700 }}>VALUE OS</div>
        <div style={{ fontSize: 13, color: C.textDim, marginTop: 4 }}>Build Skills. Create Value. Solve Problems. Build Assets.</div>
      </div>

      {mode === "reset" ? (
        resetSent ? (
          <Card><div style={{ fontSize: 13.5, lineHeight: 1.6 }}>If an account exists for that email, a reset link has been created. (Delivery by email isn't wired up yet — see the README.)</div></Card>
        ) : (
          <>
            <Field label="Email"><input style={inputStyle} type="email" autoCapitalize="none" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
            {error && <div style={{ fontSize: 12.5, color: C.rose, marginBottom: 12 }}>{error}</div>}
            <Button full onClick={submit} disabled={busy}>{busy ? <Loader2 size={15} style={{ animation: "spin 1s linear infinite" }} /> : "Send reset link"}</Button>
          </>
        )
      ) : (
        <>
          {mode === "signup" && <Field label="Name"><input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name" /></Field>}
          <Field label="Email"><input style={inputStyle} type="email" autoCapitalize="none" value={email} onChange={(e) => setEmail(e.target.value)} /></Field>
          <Field label="Password"><input style={inputStyle} type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === "signup" ? "At least 8 characters" : ""} /></Field>
          {error && <div style={{ fontSize: 12.5, color: C.rose, marginBottom: 12 }}>{error}</div>}
          <Button full onClick={submit} disabled={busy}>{busy ? <Loader2 size={15} style={{ animation: "spin 1s linear infinite" }} /> : mode === "signup" ? "Create account" : "Log in"}</Button>
        </>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", marginTop: 18 }}>
        {mode !== "reset" ? (
          <>
            <button onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(null); }} style={{ background: "none", border: "none", color: C.textDim, fontSize: 12.5 }}>
              {mode === "login" ? "Need an account? Sign up" : "Have an account? Log in"}
            </button>
            {mode === "login" && <button onClick={() => { setMode("reset"); setError(null); }} style={{ background: "none", border: "none", color: C.textFaint, fontSize: 12.5 }}>Forgot password?</button>}
          </>
        ) : (
          <button onClick={() => { setMode("login"); setResetSent(false); setError(null); }} style={{ background: "none", border: "none", color: C.textDim, fontSize: 12.5 }}>Back to login</button>
        )}
      </div>

      <div style={{ marginTop: 28 }}><GetAppCard /></div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* APP                                                                    */
/* ---------------------------------------------------------------------- */
export default function App() {
  const [loaded, setLoaded] = useState(false);
  const [authed, setAuthed] = useState(false);
  const [offline, setOffline] = useState(false);
  const [view, setView] = useState("home");
  const [profile, setProfile] = useState(seedProfile());
  const [skills, setSkills] = useState([]);
  const [missions, setMissions] = useState([]);
  const [projects, setProjects] = useState([]);
  const [finance, setFinance] = useState([]);
  const [assets, setAssets] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [focusSessions, setFocusSessions] = useState([]);
  const [toast, setToast] = useState(null);
  const [timers, setTimers] = useState({});
  const firstLoad = useRef(true);
  const syncTimer = useRef(null);

  // Postgres (via /api/state) is the source of truth. localStorage is kept
  // only as an offline cache — never the primary store.
  const applyState = (s) => {
    setProfile({ ...seedProfile(), ...s.profile });
    setSkills(s.skills || []); setMissions(s.missions || []); setProjects(s.projects || []);
    setFinance(s.finance || []); setAssets(s.assets || []); setReviews(s.reviews || []);
    setFocusSessions(s.focusSessions || []);
  };

  const bootstrap = async () => {
    setLoaded(false);
    try {
      const meRes = await fetch("/api/auth/me");
      const me = meRes.ok ? await meRes.json() : { authenticated: false };
      if (!me.authenticated) { setAuthed(false); saveKey("vos_was_authed", false); setLoaded(true); firstLoad.current = false; return; }
      setAuthed(true); saveKey("vos_was_authed", true);
      const stateRes = await fetch("/api/state");
      if (stateRes.ok) {
        const remote = await stateRes.json();
        applyState(remote);
        setOffline(false);
        [["vos_profile", remote.profile], ["vos_skills", remote.skills], ["vos_missions", remote.missions],
          ["vos_projects", remote.projects], ["vos_finance", remote.finance], ["vos_assets", remote.assets],
          ["vos_reviews", remote.reviews], ["vos_focus_sessions", remote.focusSessions]].forEach(([k, v]) => saveKey(k, v));
      } else {
        throw new Error("state fetch failed");
      }
    } catch (e) {
      // The network itself is unreachable (not just "not logged in"). If this
      // device was authenticated last time it synced, stay logged in and use
      // the local cache rather than bouncing a real user to the login screen
      // just because they're offline.
      const wasAuthed = await loadKey("vos_was_authed", false);
      setAuthed(!!wasAuthed);
      if (wasAuthed) {
        const [p, s, m, pr, f, a, r, fs] = await Promise.all([
          loadKey("vos_profile", seedProfile()), loadKey("vos_skills", []), loadKey("vos_missions", []),
          loadKey("vos_projects", []), loadKey("vos_finance", []), loadKey("vos_assets", []),
          loadKey("vos_reviews", []), loadKey("vos_focus_sessions", []),
        ]);
        applyState({ profile: p, skills: s, missions: m, projects: pr, finance: f, assets: a, reviews: r, focusSessions: fs });
        setOffline(true);
      }
    }
    setLoaded(true); firstLoad.current = false;
  };

  useEffect(() => { bootstrap(); }, []);

  // Debounced full-state sync to Postgres. Also mirrors to localStorage
  // instantly so the app keeps working offline between syncs.
  useEffect(() => {
    if (firstLoad.current || !authed) return;
    saveKey("vos_profile", profile); saveKey("vos_skills", skills); saveKey("vos_missions", missions);
    saveKey("vos_projects", projects); saveKey("vos_finance", finance); saveKey("vos_assets", assets);
    saveKey("vos_reviews", reviews); saveKey("vos_focus_sessions", focusSessions);
    if (syncTimer.current) clearTimeout(syncTimer.current);
    syncTimer.current = setTimeout(() => {
      fetch("/api/state", {
        method: "PUT", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ profile, skills, missions, projects, finance, assets, reviews, focusSessions }),
      }).then((r) => setOffline(!r.ok)).catch(() => setOffline(true));
    }, 800);
    return () => clearTimeout(syncTimer.current);
  }, [profile, skills, missions, projects, finance, assets, reviews, focusSessions, authed]);

  const logout = async () => {
    try { await fetch("/api/auth/logout", { method: "POST" }); } catch (e) {}
    saveKey("vos_was_authed", false);
    setAuthed(false); setLoaded(true);
    setProfile(seedProfile()); setSkills([]); setMissions([]); setProjects([]);
    setFinance([]); setAssets([]); setReviews([]); setFocusSessions([]);
  };

  // Achievement unlock detection — fires once per newly-met condition.
  useEffect(() => {
    if (firstLoad.current) return;
    const state = { profile, skills, missions, projects, finance };
    const unlocked = profile.achievementsUnlocked || {};
    const next = { ...unlocked };
    let firstNew = null;
    ACHIEVEMENTS.forEach((a) => {
      if (!next[a.id] && a.check(state)) { next[a.id] = todayStr(); if (!firstNew) firstNew = a; }
    });
    if (firstNew) {
      setProfile((p) => ({ ...p, achievementsUnlocked: next }));
      flash(`🏆 Achievement unlocked: ${firstNew.label}`);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile.missionsCompleted, profile.streak, skills, projects, finance]);

  // Recompute today's score into history whenever missions change
  useEffect(() => {
    if (firstLoad.current) return;
    const today = todayStr();
    const score = scoreForDate(missions, today);
    setProfile((p) => {
      const hist = (p.scoreHistory || []).filter((h) => h.date !== today);
      return { ...p, scoreHistory: [...hist, { date: today, score }].slice(-60) };
    });
  }, [missions]);

  // Timer ticking
  useEffect(() => {
    const iv = setInterval(() => {
      setTimers((t) => {
        let changed = false;
        const next = { ...t };
        Object.keys(next).forEach((id) => {
          if (next[id].running && next[id].remaining > 0) {
            next[id] = { ...next[id], remaining: next[id].remaining - 1 };
            changed = true;
            if (next[id].remaining === 0) next[id].running = false;
          }
        });
        return changed ? next : t;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, []);

  const toggleTimer = (id, totalSec) => setTimers((t) => {
    const cur = t[id] || { remaining: totalSec, running: false };
    return { ...t, [id]: { ...cur, running: !cur.running } };
  });
  const resetTimer = (id, totalSec) => setTimers((t) => ({ ...t, [id]: { remaining: totalSec, running: false } }));

  const flash = (msg) => { setToast(msg); setTimeout(() => setToast(null), 2200); };

  const gainXp = useCallback((amount) => {
    setProfile((p) => {
      const today = todayStr();
      let streak = p.streak;
      if (p.lastActiveDate !== today) {
        const y = new Date(); y.setDate(y.getDate() - 1);
        const yesterday = y.toISOString().slice(0, 10);
        streak = p.lastActiveDate === yesterday ? p.streak + 1 : 1;
      }
      return { ...p, xp: p.xp + amount, lastActiveDate: today, streak };
    });
  }, []);

  const completeMission = (id) => {
    const m = missions.find((x) => x.id === id);
    if (!m || m.done) return;
    const xp = diffXp(m.difficulty);
    gainXp(xp);
    setProfile((p) => ({ ...p, missionsCompleted: p.missionsCompleted + 1 }));
    if (m.skillId) setSkills((sk) => sk.map((s) => s.id === m.skillId ? { ...s, xp: s.xp + xp } : s));
    flash(`+${xp} XP · ${categoryOf(m.category).label}`);
    setMissions((ms) => ms.map((mm) => mm.id === id ? { ...mm, done: true } : mm));
  };
  const uncompleteMission = (id) => setMissions((ms) => ms.map((m) => m.id === id ? { ...m, done: false } : m));
  const deleteMission = (id) => setMissions((ms) => ms.filter((m) => m.id !== id));
  const addMission = (data) => setMissions((ms) => [{ id: uid(), done: false, date: todayStr(), ...data }, ...ms]);
  const addMissions = (list) => setMissions((ms) => [...list.map((d) => ({ id: uid(), done: false, date: todayStr(), ...d })), ...ms]);

  const addSkill = (data) => setSkills((s) => [...s, { id: uid(), xp: 0, prerequisites: [], resources: [], practiceTasks: [], linkedProjectIds: [], ...data }]);
  const updateSkill = (id, patch) => setSkills((s) => s.map((sk) => sk.id === id ? { ...sk, ...patch } : sk));
  const deleteSkill = (id) => setSkills((s) => s.filter((sk) => sk.id !== id));
  const toggleTask = (skillId, taskId) => setSkills((s) => s.map((sk) => {
    if (sk.id !== skillId) return sk;
    let delta = 0;
    const tasks = sk.practiceTasks.map((t) => {
      if (t.id !== taskId) return t;
      delta = t.done ? -t.xp : t.xp;
      return { ...t, done: !t.done };
    });
    return { ...sk, practiceTasks: tasks, xp: Math.max(0, sk.xp + delta) };
  }));

  const addProject = (data) => setProjects((p) => [{ id: uid(), progress: 0, createdAt: todayStr(), status: "Active", stage: "Idea", revenue: 0, expenses: 0, tasks: [], links: [], notes: "", ...data }, ...p]);
  const updateProject = (id, patch) => setProjects((p) => p.map((pr) => pr.id === id ? { ...pr, ...patch } : pr));
  const deleteProject = (id) => setProjects((p) => p.filter((pr) => pr.id !== id));

  const addFinance = (data) => setFinance((f) => [{ id: uid(), date: todayStr(), ...data }, ...f]);
  const deleteFinance = (id) => setFinance((f) => f.filter((x) => x.id !== id));
  const addAsset = (data) => setAssets((a) => [{ id: uid(), date: todayStr(), ...data }, ...a]);
  const deleteAsset = (id) => setAssets((a) => a.filter((x) => x.id !== id));
  const addReview = (data) => setReviews((r) => [{ id: uid(), date: todayStr(), ...data }, ...r]);
  const addFocusSession = (data) => setFocusSessions((f) => [{ id: uid(), date: todayStr(), ...data }, ...f]);
  const addCheckin = (data) => setProfile((p) => ({ ...p, checkins: [{ id: uid(), date: todayStr(), ...data }, ...(p.checkins || [])] }));

  const resetAll = () => {
    setProfile(seedProfile()); setSkills([]); setMissions([]); setProjects([]); setFinance([]); setAssets([]); setReviews([]); setFocusSessions([]);
    flash("All data cleared");
  };

  const completeOnboarding = (answers, roadmap) => {
    setProfile((p) => ({ ...p, ...answers, onboarded: true, roadmap }));
    if (roadmap) {
      if (roadmap.recommendedSkills?.length) {
        setSkills((s) => [...s, ...roadmap.recommendedSkills.map((rs) => ({
          id: uid(), name: rs.name, group: SKILL_GROUPS.find((g) => g.id === rs.group) ? rs.group : "technology",
          subcategory: rs.subcategory || "", xp: 0, prerequisites: [], resources: [], practiceTasks: [], linkedProjectIds: [],
        }))]);
      }
      if (roadmap.recommendedProjects?.length) {
        setProjects((pr) => [...roadmap.recommendedProjects.map((rp) => ({
          id: uid(), name: rp.name, description: rp.description, problem: "", targetUsers: "", solution: "",
          stage: "Idea", status: "Active", progress: 0, deadline: "", revenue: 0, expenses: 0, notes: "", links: [], tasks: [],
          createdAt: todayStr(),
        })), ...pr]);
      }
      if (roadmap.dailyActions?.length) {
        addMissions(roadmap.dailyActions.map((d) => ({ title: d, category: "execution", difficulty: "medium", estimatedMinutes: 30, recurring: false })));
      }
    }
    flash(`Welcome, ${answers.name}.`);
  };

  if (!loaded) {
    return (
      <div style={{ minHeight: 500, display: "flex", alignItems: "center", justifyContent: "center", background: C.bg }}>
        <style>{FONTS}</style>
        <Loader2 size={22} color={C.accent} style={{ animation: "spin 1s linear infinite" }} />
      </div>
    );
  }

  if (!authed) {
    return <AuthView onAuthed={bootstrap} />;
  }

  if (!profile.onboarded) {
    return <Onboarding onComplete={completeOnboarding} />;
  }

  const ctx = {
    profile, skills, missions, projects, finance, assets, reviews, focusSessions, timers, gainXp, flash,
    completeMission, uncompleteMission, deleteMission, addMission, addMissions,
    addSkill, updateSkill, deleteSkill, toggleTask,
    addProject, updateProject, deleteProject,
    addFinance, deleteFinance, addAsset, deleteAsset,
    addReview, addFocusSession, addCheckin,
    resetAll, setProfile, setView,
    toggleTimer, resetTimer, logout, offline,
  };

  const NAV = [
    { id: "home", label: "Home", icon: HomeIcon },
    { id: "missions", label: "Missions", icon: Target },
    { id: "skills", label: "Skills", icon: Sparkles },
    { id: "projects", label: "Projects", icon: FolderKanban },
    { id: "profile", label: "Profile", icon: User },
  ];

  const views = {
    home: <HomeView {...ctx} />, missions: <MissionsView {...ctx} />, skills: <SkillsView {...ctx} />,
    projects: <ProjectsView {...ctx} />, profile: <ProfileView {...ctx} />, mentor: <MentorView {...ctx} />,
    lab: <OpportunityLabView {...ctx} />, analytics: <AnalyticsView {...ctx} />, finance: <FinanceView {...ctx} />,
    review: <WeeklyReviewView {...ctx} />, settings: <SettingsView {...ctx} />, subscription: <SubscriptionView {...ctx} />,
    focus: <FocusView {...ctx} />,
  };

  return (
    <div style={{ background: C.bg, minHeight: "100vh", maxWidth: 480, margin: "0 auto", position: "relative", color: C.text }}>
      <style>{FONTS}</style>
      <div style={{ paddingBottom: 90 }}>{views[view] || views.home}</div>
      {offline && (
        <div style={{ position: "fixed", top: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: C.amberSoft, color: C.amber, textAlign: "center", fontSize: 11.5, fontWeight: 600, padding: "6px 0", zIndex: 60 }}>
          Offline — changes are saved locally and will sync when you're back online.
        </div>
      )}
      {toast && (
        <div style={{ position: "fixed", bottom: 96, left: "50%", transform: "translateX(-50%)", background: C.surfaceHi, border: `1px solid ${C.border}`, color: C.text, padding: "10px 16px", borderRadius: 999, fontSize: 13, fontWeight: 600, zIndex: 200, boxShadow: "0 8px 24px rgba(0,0,0,0.4)", maxWidth: 420 }} className="rise">{toast}</div>
      )}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: "rgba(15,18,24,0.92)", backdropFilter: "blur(10px)", borderTop: `1px solid ${C.border}`, display: "flex", padding: "10px 6px 14px", zIndex: 50 }}>
        {NAV.map((n) => {
          const active = view === n.id; const Icon = n.icon;
          return (
            <button key={n.id} onClick={() => setView(n.id)} style={{ flex: 1, background: "transparent", border: "none", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, padding: "6px 0", cursor: "pointer" }}>
              <Icon size={20} color={active ? C.accent : C.textFaint} strokeWidth={active ? 2.3 : 1.9} />
              <span style={{ fontSize: 10.5, fontWeight: 600, color: active ? C.accent : C.textFaint }}>{n.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* HOME                                                                    */
/* ---------------------------------------------------------------------- */
function HomeView({ profile, missions, projects, completeMission, uncompleteMission, addMissions, timers, toggleTimer, resetTimer, skills, flash, setView, addCheckin }) {
  const today = todayStr();
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const [genBusy, setGenBusy] = useState(false);
  const [blockedText, setBlockedText] = useState("");
  const [checkinDone, setCheckinDone] = useState(false);

  const y = new Date(); y.setDate(y.getDate() - 1);
  const yesterday = y.toISOString().slice(0, 10);
  const missedYesterday = missions.filter((m) => m.date === yesterday && !m.done && !m.recurring);
  const plannedMinutesYesterday = missions.filter((m) => m.date === yesterday).reduce((s, m) => s + (m.estimatedMinutes || 0), 0);
  const doneMinutesYesterday = missions.filter((m) => m.date === yesterday && m.done).reduce((s, m) => s + (m.estimatedMinutes || 0), 0);
  const alreadyCheckedIn = (profile.checkins || []).some((c) => c.date === today && c.forDate === yesterday);
  const showCheckin = missedYesterday.length > 0 && !alreadyCheckedIn && !checkinDone;

  const todaysScore = scoreForDate(missions, today);
  const hist = profile.scoreHistory || [];
  const last7 = hist.filter((h) => { const d = (Date.now() - new Date(h.date).getTime()) / 86400000; return d < 7; });
  const weeklyAvg = last7.length ? Math.round(last7.reduce((s, h) => s + h.score, 0) / last7.length) : todaysScore;
  const bestScore = hist.length ? Math.max(...hist.map((h) => h.score), todaysScore) : todaysScore;

  const directive = missions.filter((m) => m.date === today);
  const activeDirective = directive.filter((m) => !m.done);
  const catBreakdown = CATEGORIES.map((c) => ({ ...c, xp: missions.filter((m) => m.done && m.date === today && m.category === c.id).reduce((s, m) => s + diffXp(m.difficulty), 0) }));

  const QUICK = [
    { id: "focus", label: "Focus Mode", icon: Target, color: C.accent },
    { id: "mentor", label: "AI Mentor", icon: MessageCircle, color: C.blue },
    { id: "lab", label: "Opportunity Lab", icon: Lightbulb, color: C.amber },
    { id: "analytics", label: "Analytics", icon: BarChart3, color: C.violet },
    { id: "finance", label: "Finance", icon: Wallet, color: C.teal },
  ];

  const generateDirective = async () => {
    setGenBusy(true);
    const weakCat = catBreakdown.slice().sort((a, b) => a.xp - b.xp)[0];
    const system = `You are the Daily Directive Engine inside VALUE OS. Generate 3-7 highly specific, ACTION-based missions for today — never passive tasks like "read a motivational quote". Favor concrete verbs: build, write, ship, contact, analyze, practice, publish. Ground every mission in the user's real goal, skills, and current weak area. Respond ONLY with a raw JSON array (no markdown fences) of objects with keys:
"title" (string, specific and concrete), "category" (one of: learning, skill_practice, building, problem_solving, execution, comm_sales, health), "estimatedMinutes" (number), "priority" ("High"|"Medium"|"Low"), "reason" (short string: why this matters today), "difficulty" ("easy"|"medium"|"hard").`;
    const user = `Goal: ${profile.mainGoal || "not set"}\nCurrent priority: ${profile.roadmap?.currentPriority || "not set"}\nSkills: ${skills.map((s) => `${s.name} (Lv${levelFromXp(s.xp)})`).join(", ") || "none"}\nActive projects: ${projects.filter((p) => p.status === "Active").map((p) => `${p.name} (${p.stage})`).join(", ") || "none"}\nDaily time available: ${profile.dailyTime || "unspecified"}\nCompleted missions so far: ${profile.missionsCompleted}\nCurrent streak: ${profile.streak} days\nWeakest category this period: ${weakCat.label}\nAvoid duplicating: ${activeDirective.map((m) => m.title).join("; ") || "nothing yet"}`;
    try {
      const raw = await askClaude(system, [{ role: "user", content: user }]);
      const list = parseJsonLoose(raw, []);
      if (Array.isArray(list) && list.length) {
        addMissions(list.map((m) => ({ ...m, category: CATEGORIES.find((c) => c.id === m.category) ? m.category : "execution" })));
        flash(`${list.length} missions added`);
      } else flash("Couldn't generate missions — try again");
    } catch (e) { flash("Couldn't reach the AI — try again"); }
    finally { setGenBusy(false); }
  };

  return (
    <div>
      <div style={{ padding: "20px 20px 4px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ fontSize: 13, color: C.textDim, fontWeight: 500 }}>{greet}</div>
          <h1 className="font-display" style={{ fontSize: 23, fontWeight: 700, margin: "2px 0 0" }}>{profile.name}</h1>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, background: C.amberSoft, padding: "8px 12px", borderRadius: 999 }}>
          <Flame size={15} color={C.amber} />
          <span style={{ fontSize: 14, fontWeight: 700, color: C.amber }}>{profile.streak}</span>
        </div>
      </div>

      {profile.roadmap?.currentPriority && (
        <div style={{ padding: "14px 20px 0" }}>
          <Card style={{ borderColor: "rgba(74,222,158,0.3)", background: `linear-gradient(135deg, ${C.accentSoft}, ${C.surface})` }}>
            <div style={{ fontSize: 10.5, fontWeight: 700, color: C.accent, letterSpacing: 0.5, marginBottom: 6 }}>CURRENT PRIORITY</div>
            <div style={{ fontSize: 13.5, fontWeight: 600, lineHeight: 1.5 }}>{profile.roadmap.currentPriority}</div>
          </Card>
        </div>
      )}

      {showCheckin && (
        <div style={{ padding: "14px 20px 0" }}>
          <Card style={{ borderColor: "rgba(232,178,77,0.35)" }}>
            <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
              <AlertTriangle size={15} color={C.amber} style={{ flexShrink: 0, marginTop: 1 }} />
              <div style={{ fontSize: 13, fontWeight: 600, lineHeight: 1.45 }}>
                You planned {plannedMinutesYesterday} min yesterday and completed {doneMinutesYesterday}. {missedYesterday.length} mission{missedYesterday.length === 1 ? "" : "s"} didn't get done. What blocked you?
              </div>
            </div>
            <textarea style={{ ...inputStyle, minHeight: 55, fontSize: 12.5 }} placeholder="Be honest — this isn't a scoreboard, it's a pattern-finder." value={blockedText} onChange={(e) => setBlockedText(e.target.value)} />
            <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
              <Button variant="secondary" style={{ flex: 1, padding: "9px 12px", fontSize: 12.5 }} onClick={() => setCheckinDone(true)}>Skip</Button>
              <Button style={{ flex: 1, padding: "9px 12px", fontSize: 12.5 }} disabled={!blockedText.trim()} onClick={() => { addCheckin({ forDate: yesterday, blocked: blockedText.trim(), missedCount: missedYesterday.length }); setCheckinDone(true); }}>Log it</Button>
            </div>
          </Card>
        </div>
      )}

      <div style={{ padding: "16px 20px 0" }}>
        <div style={{ fontSize: 12, color: C.textDim, fontWeight: 600, marginBottom: 10 }}>TODAY'S VALUE SCORE</div>
        <Card style={{ background: `linear-gradient(155deg, ${C.surface}, ${C.bgElevated})` }}>
          <div style={{ display: "flex", alignItems: "flex-end", gap: 6, marginBottom: 16 }}>
            <span className="font-display" style={{ fontSize: 46, fontWeight: 700, color: C.accent, lineHeight: 1 }}>{todaysScore}</span>
            <span style={{ fontSize: 15, color: C.textFaint, marginBottom: 6 }}>/ 100</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
            <div style={{ textAlign: "center" }}><div className="font-display" style={{ fontSize: 16, fontWeight: 700 }}>{weeklyAvg}</div><div style={{ fontSize: 9.5, color: C.textFaint, fontWeight: 600, marginTop: 2 }}>WEEKLY AVG</div></div>
            <div style={{ textAlign: "center" }}><div className="font-display" style={{ fontSize: 16, fontWeight: 700 }}>{profile.streak}</div><div style={{ fontSize: 9.5, color: C.textFaint, fontWeight: 600, marginTop: 2 }}>STREAK</div></div>
            <div style={{ textAlign: "center" }}><div className="font-display" style={{ fontSize: 16, fontWeight: 700 }}>{bestScore}</div><div style={{ fontSize: 9.5, color: C.textFaint, fontWeight: 600, marginTop: 2 }}>BEST</div></div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6, marginTop: 16 }}>
            {catBreakdown.map((c) => (
              <div key={c.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 10.5, color: C.textDim, width: 92, flexShrink: 0 }}>{c.label}</span>
                <ProgressBar value={(c.xp / 30) * 100} color={c.color} height={5} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div style={{ padding: "22px 20px 8px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <h2 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>Today's Directive</h2>
        <button onClick={generateDirective} disabled={genBusy} style={{ background: "none", border: "none", color: C.accent, fontSize: 12, fontWeight: 700, display: "flex", alignItems: "center", gap: 5 }}>
          {genBusy ? <Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> : <Wand2 size={13} />} Generate with AI
        </button>
      </div>
      <div style={{ padding: "0 20px", display: "flex", flexDirection: "column", gap: 10 }}>
        {activeDirective.length === 0 ? (
          <EmptyState icon={Target} title="No directive yet" sub="Let the AI build today's missions around your goal and roadmap, or add your own from Missions."
            action={<Button onClick={generateDirective} disabled={genBusy}>{genBusy ? "Generating…" : "Generate today's directive"}</Button>} />
        ) : activeDirective.slice(0, 5).map((m, i) => (
          <MissionRow key={m.id} mission={m} numberLabel={`MISSION ${String(i + 1).padStart(2, "0")}`}
            onComplete={completeMission} onUncomplete={uncompleteMission}
            timer={timers[m.id]} onTimerToggle={toggleTimer} onTimerReset={resetTimer} />
        ))}
        {activeDirective.length > 5 && (
          <button onClick={() => setView("missions")} style={{ background: "none", border: "none", color: C.accent, fontSize: 13, fontWeight: 600, padding: "6px 0", textAlign: "left" }}>+{activeDirective.length - 5} more →</button>
        )}
      </div>

      <div style={{ padding: "24px 20px 8px" }}>
        <h2 style={{ fontSize: 15, fontWeight: 700, margin: "0 0 10px" }}>Tools</h2>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
          {QUICK.map((q) => {
            const Icon = q.icon;
            return (
              <Card key={q.id} onClick={() => setView(q.id)} style={{ cursor: "pointer", padding: 14 }}>
                <div style={{ width: 34, height: 34, borderRadius: 10, background: `${q.color}1F`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
                  <Icon size={16} color={q.color} />
                </div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{q.label}</div>
              </Card>
            );
          })}
        </div>
      </div>

      {projects.length > 0 && (
        <div style={{ padding: "22px 20px 8px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <h2 style={{ fontSize: 15, fontWeight: 700, margin: 0 }}>Active projects</h2>
            <button onClick={() => setView("projects")} style={{ background: "none", border: "none", color: C.textDim, fontSize: 12, display: "flex", alignItems: "center", gap: 2 }}>All <ChevronRight size={13} /></button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {projects.slice(0, 2).map((p) => (
              <Card key={p.id} style={{ padding: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <span style={{ fontSize: 13.5, fontWeight: 600 }}>{p.name}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, color: stageColor(p.stage) }}>{p.stage}</span>
                </div>
                <ProgressBar value={p.progress} color={stageColor(p.stage)} />
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* MISSIONS                                                                */
/* ---------------------------------------------------------------------- */
function MissionsView({ missions, addMission, completeMission, uncompleteMission, deleteMission, skills, timers, toggleTimer, resetTimer }) {
  const [filter, setFilter] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const filtered = missions.filter((m) => filter === "all" || m.category === filter);
  const active = filtered.filter((m) => !m.done);
  const done = filtered.filter((m) => m.done);

  return (
    <div>
      <Header title="Missions" right={
        <button onClick={() => setShowAdd(true)} style={{ background: C.accent, border: "none", borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={18} color="#06120C" /></button>
      } />
      <div style={{ padding: "8px 20px", overflowX: "auto" }}>
        <SegPicker options={["all", ...CATEGORIES.map((c) => c.id)]} value={filter} onChange={setFilter} getLabel={(k) => k === "all" ? "All" : categoryOf(k).label} />
      </div>
      <div style={{ padding: "10px 20px 0", display: "flex", flexDirection: "column", gap: 10 }}>
        {active.length === 0 && done.length === 0 && (
          <EmptyState icon={Target} title="No missions yet" sub="Missions are small, concrete actions across Learning, Building, Problem Solving, Execution, Sales and Discipline."
            action={<Button onClick={() => setShowAdd(true)}>Add a mission</Button>} />
        )}
        {active.map((m) => (
          <MissionRow key={m.id} mission={m} onComplete={completeMission} onUncomplete={uncompleteMission} onDelete={deleteMission}
            timer={timers[m.id]} onTimerToggle={toggleTimer} onTimerReset={resetTimer} />
        ))}
        {done.length > 0 && (
          <>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginTop: 10 }}>COMPLETED</div>
            {done.map((m) => <MissionRow key={m.id} mission={m} onComplete={completeMission} onUncomplete={uncompleteMission} onDelete={deleteMission} />)}
          </>
        )}
      </div>
      {showAdd && <AddMissionModal skills={skills} onClose={() => setShowAdd(false)} onAdd={(d) => { addMission(d); setShowAdd(false); }} />}
    </div>
  );
}

function AddMissionModal({ onClose, onAdd, skills }) {
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("learning");
  const [difficulty, setDifficulty] = useState("easy");
  const [estimatedMinutes, setEstimatedMinutes] = useState(30);
  const [recurring, setRecurring] = useState(false);
  const [skillId, setSkillId] = useState("");

  return (
    <Modal title="New mission" onClose={onClose} footer={
      <Button full disabled={!title.trim()} onClick={() => onAdd({ title: title.trim(), category, difficulty, estimatedMinutes: Number(estimatedMinutes), recurring, skillId: skillId || null })}>Add mission</Button>
    }>
      <Field label="What will you do?"><input style={inputStyle} placeholder="e.g. Learn REST APIs and make one request" value={title} onChange={(e) => setTitle(e.target.value)} autoFocus /></Field>
      <Field label="Category"><SegPicker options={CATEGORIES} value={category} onChange={setCategory} getKey={(c) => c.id} getLabel={(c) => c.label} /></Field>
      <Field label="Difficulty"><SegPicker options={DIFFICULTIES} value={difficulty} onChange={setDifficulty} getKey={(d) => d.id} getLabel={(d) => `${d.label} · ${d.xp}xp`} /></Field>
      <Field label="Estimated time"><SegPicker options={[15, 30, 45, 60, 90]} value={estimatedMinutes} onChange={setEstimatedMinutes} getLabel={(m) => `${m} min`} /></Field>
      {skills.length > 0 && (
        <Field label="Link to a skill (optional)"><SegPicker options={["", ...skills.map((s) => s.id)]} value={skillId} onChange={setSkillId} getLabel={(k) => k === "" ? "None" : skills.find((s) => s.id === k)?.name} /></Field>
      )}
      <label style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 13.5, color: C.text, marginTop: 4 }}>
        <input type="checkbox" checked={recurring} onChange={(e) => setRecurring(e.target.checked)} style={{ width: 16, height: 16 }} /> Repeat this daily
      </label>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- */
/* SKILL TREE                                                              */
/* ---------------------------------------------------------------------- */
function SkillsView({ skills, addSkill, updateSkill, deleteSkill, toggleTask, projects }) {
  const [showAdd, setShowAdd] = useState(false);
  const [openId, setOpenId] = useState(null);
  const [expanded, setExpanded] = useState(() => Object.fromEntries(SKILL_GROUPS.map((g) => [g.id, true])));
  const open = skills.find((s) => s.id === openId);

  return (
    <div>
      <Header title="Skill Tree" right={
        <button onClick={() => setShowAdd(true)} style={{ background: C.accent, border: "none", borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={18} color="#06120C" /></button>
      } />
      <div style={{ padding: "10px 20px 0", display: "flex", flexDirection: "column", gap: 14 }}>
        {skills.length === 0 && (
          <EmptyState icon={Sparkles} title="No skills tracked yet" sub="Add the skills you're building. XP comes from completed missions and practice tasks — not clicking buttons."
            action={<Button onClick={() => setShowAdd(true)}>Add a skill</Button>} />
        )}
        {SKILL_GROUPS.map((g) => {
          const groupSkills = skills.filter((s) => s.group === g.id);
          if (groupSkills.length === 0) return null;
          const isOpen = expanded[g.id];
          return (
            <div key={g.id}>
              <button onClick={() => setExpanded((e) => ({ ...e, [g.id]: !e[g.id] }))} style={{ width: "100%", background: "none", border: "none", display: "flex", alignItems: "center", justifyContent: "space-between", padding: "4px 0 10px", cursor: "pointer" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ width: 8, height: 8, borderRadius: 999, background: g.color }} />
                  <span style={{ fontSize: 13.5, fontWeight: 700, color: C.text }}>{g.label}</span>
                  <span style={{ fontSize: 11.5, color: C.textFaint }}>({groupSkills.length})</span>
                </div>
                <ChevronDown size={16} color={C.textFaint} style={{ transform: isOpen ? "rotate(0deg)" : "rotate(-90deg)", transition: "transform .15s" }} />
              </button>
              {isOpen && (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {groupSkills.map((s) => {
                    const lvl = levelFromXp(s.xp);
                    const doneTasks = s.practiceTasks.filter((t) => t.done).length;
                    return (
                      <Card key={s.id} onClick={() => setOpenId(s.id)} style={{ padding: 16, cursor: "pointer" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                          <div>
                            <div style={{ fontSize: 15, fontWeight: 700 }}>{s.name}</div>
                            <div style={{ fontSize: 11.5, color: C.textDim, marginTop: 2 }}>{s.subcategory || g.label}</div>
                          </div>
                          <div className="font-display" style={{ fontSize: 18, fontWeight: 700, color: g.color }}>Lv {lvl}</div>
                        </div>
                        <ProgressBar value={xpIntoLevel(s.xp)} color={g.color} />
                        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 10, fontSize: 11, color: C.textFaint }}>
                          <span>{s.xp} XP total</span>
                          <span>{doneTasks}/{s.practiceTasks.length} tasks done</span>
                        </div>
                      </Card>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
      {showAdd && <AddSkillModal onClose={() => setShowAdd(false)} onAdd={(d) => { addSkill(d); setShowAdd(false); }} />}
      {open && <SkillDetailModal skill={open} projects={projects} onClose={() => setOpenId(null)} onUpdate={(patch) => updateSkill(open.id, patch)} onToggleTask={(tid) => toggleTask(open.id, tid)} onDelete={() => { deleteSkill(open.id); setOpenId(null); }} />}
    </div>
  );
}

function AddSkillModal({ onClose, onAdd }) {
  const [name, setName] = useState("");
  const [group, setGroup] = useState(SKILL_GROUPS[0].id);
  const [subcategory, setSubcategory] = useState(SKILL_GROUPS[0].subs[0]);
  const [prereq, setPrereq] = useState("");
  const g = groupOf(group);
  return (
    <Modal title="Add a skill" onClose={onClose} footer={
      <Button full disabled={!name.trim()} onClick={() => onAdd({ name: name.trim(), group, subcategory, prerequisites: prereq.split(",").map((x) => x.trim()).filter(Boolean) })}>Add skill</Button>
    }>
      <Field label="Skill name"><input style={inputStyle} placeholder="e.g. Python, Copywriting, Negotiation" value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field>
      <Field label="Category"><SegPicker options={SKILL_GROUPS} value={group} onChange={(v) => { setGroup(v); setSubcategory(groupOf(v).subs[0]); }} getKey={(x) => x.id} getLabel={(x) => x.label} /></Field>
      <Field label="Subcategory"><SegPicker options={g.subs} value={subcategory} onChange={setSubcategory} /></Field>
      <Field label="Prerequisites (optional)"><input style={inputStyle} placeholder="Comma-separated skill names" value={prereq} onChange={(e) => setPrereq(e.target.value)} /></Field>
    </Modal>
  );
}

function SkillDetailModal({ skill, projects, onClose, onUpdate, onToggleTask, onDelete }) {
  const [newResource, setNewResource] = useState("");
  const [newTask, setNewTask] = useState("");
  const [newTaskXp, setNewTaskXp] = useState(20);
  const g = groupOf(skill.group);
  const lvl = levelFromXp(skill.xp);
  const milestoneLevels = [2, 3, 4, 5, 6];

  const addResource = () => { if (!newResource.trim()) return; onUpdate({ resources: [...skill.resources, newResource.trim()] }); setNewResource(""); };
  const addTask = () => { if (!newTask.trim()) return; onUpdate({ practiceTasks: [...skill.practiceTasks, { id: uid(), label: newTask.trim(), xp: Number(newTaskXp) || 20, done: false }] }); setNewTask(""); };
  const toggleProject = (pid) => onUpdate({ linkedProjectIds: skill.linkedProjectIds.includes(pid) ? skill.linkedProjectIds.filter((x) => x !== pid) : [...skill.linkedProjectIds, pid] });

  return (
    <Modal title={skill.name} onClose={onClose}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
        <Tag label={g.label} color={g.color} />
        <Tag label={skill.subcategory || "General"} color={C.textFaint} />
      </div>
      <Card style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span className="font-display" style={{ fontSize: 20, fontWeight: 700, color: g.color }}>Level {lvl}</span>
          <span style={{ fontSize: 12, color: C.textDim }}>{skill.xp} XP total</span>
        </div>
        <ProgressBar value={xpIntoLevel(skill.xp)} color={g.color} />
      </Card>

      {skill.prerequisites?.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>PREREQUISITES</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>{skill.prerequisites.map((p, i) => <Tag key={i} label={p} color={C.textFaint} />)}</div>
        </div>
      )}

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>MILESTONES</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          {milestoneLevels.map((lv) => {
            const unlocked = lvl >= lv;
            return (
              <div key={lv} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12.5, color: unlocked ? C.text : C.textFaint }}>
                {unlocked ? <Check size={13} color={g.color} /> : <Lock size={12} color={C.textFaint} />}
                Reach Level {lv} ({(lv - 1) * 100} XP)
              </div>
            );
          })}
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>PRACTICE TASKS</div>
        {skill.practiceTasks.length === 0 && <div style={{ fontSize: 12.5, color: C.textFaint, marginBottom: 8 }}>No practice tasks yet — add concrete ones below.</div>}
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 10 }}>
          {skill.practiceTasks.map((t) => (
            <div key={t.id} onClick={() => onToggleTask(t.id)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 11px", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, cursor: "pointer" }}>
              <div style={{ width: 18, height: 18, borderRadius: 5, border: `2px solid ${t.done ? g.color : C.textFaint}`, background: t.done ? g.color : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                {t.done && <Check size={11} color="#06120C" />}
              </div>
              <span style={{ flex: 1, fontSize: 12.5, textDecoration: t.done ? "line-through" : "none", color: t.done ? C.textFaint : C.text }}>{t.label}</span>
              <span style={{ fontSize: 11, color: C.textFaint }}>+{t.xp}xp</span>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <input style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }} placeholder="e.g. Build a to-do list app" value={newTask} onChange={(e) => setNewTask(e.target.value)} />
          <input style={{ ...inputStyle, width: 56, padding: "8px 6px", fontSize: 12.5, textAlign: "center" }} type="number" value={newTaskXp} onChange={(e) => setNewTaskXp(e.target.value)} />
          <Button onClick={addTask} style={{ padding: "8px 12px" }}><Plus size={14} /></Button>
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>RESOURCES</div>
        {skill.resources.map((r, i) => <div key={i} style={{ fontSize: 12.5, color: C.textDim, marginBottom: 5 }}>• {r}</div>)}
        <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
          <input style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }} placeholder="Book, course, article title…" value={newResource} onChange={(e) => setNewResource(e.target.value)} />
          <Button onClick={addResource} style={{ padding: "8px 12px" }}><Plus size={14} /></Button>
        </div>
      </div>

      {projects.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>LINKED PROJECTS</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {projects.map((p) => {
              const active = skill.linkedProjectIds.includes(p.id);
              return <button key={p.id} onClick={() => toggleProject(p.id)} style={{ fontSize: 12, fontWeight: 600, padding: "6px 11px", borderRadius: 999, background: active ? C.accentSoft : C.surface, color: active ? C.accent : C.textDim, border: `1px solid ${active ? "rgba(74,222,158,0.4)" : C.border}` }}>{p.name}</button>;
            })}
          </div>
        </div>
      )}

      <Button variant="danger" full onClick={onDelete}><Trash2 size={14} /> Remove skill</Button>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- */
/* PROJECTS                                                                */
/* ---------------------------------------------------------------------- */
function ProjectsView({ projects, addProject, updateProject, deleteProject }) {
  const [showAdd, setShowAdd] = useState(false);
  const [openId, setOpenId] = useState(null);
  const open = projects.find((p) => p.id === openId);

  const totalRevenue = projects.reduce((s, p) => s + (Number(p.revenue) || 0), 0);
  const totalExpenses = projects.reduce((s, p) => s + (Number(p.expenses) || 0), 0);
  const activeCount = projects.filter((p) => p.status === "Active").length;
  const funnelData = PROJECT_STAGES.map((st) => ({ name: st, value: projects.filter((p) => p.stage === st).length, color: stageColor(st) }));

  return (
    <div>
      <Header title="Projects" right={
        <button onClick={() => setShowAdd(true)} style={{ background: C.accent, border: "none", borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={18} color="#06120C" /></button>
      } />
      <div style={{ padding: "10px 20px 0" }}>
        {projects.length > 0 && (
          <>
            <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
              <StatBox label="Active" value={activeCount} icon={FolderKanban} color={C.accent} />
              <StatBox label="Revenue" value={totalRevenue.toLocaleString()} icon={TrendingUp} color={C.teal} />
              <StatBox label="Expenses" value={totalExpenses.toLocaleString()} icon={TrendingDown} color={C.rose} />
            </div>
            <Card style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, marginBottom: 10 }}>Pipeline</div>
              <div style={{ height: 140 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={funnelData}>
                    <XAxis dataKey="name" tick={{ fill: C.textFaint, fontSize: 8.5 }} axisLine={{ stroke: C.border }} tickLine={false} interval={0} angle={-35} textAnchor="end" height={50} />
                    <YAxis allowDecimals={false} tick={{ fill: C.textFaint, fontSize: 10 }} axisLine={false} tickLine={false} width={20} />
                    <Tooltip contentStyle={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 10, fontSize: 12 }} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                    <Bar dataKey="value" radius={[5, 5, 0, 0]}>{funnelData.map((d, i) => <Cell key={i} fill={d.color} />)}</Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card>
          </>
        )}

        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {projects.length === 0 && (
            <EmptyState icon={FolderKanban} title="No projects yet" sub="A project moves through Idea → Problem → Validation → MVP → Launch → Feedback → Iteration → Revenue → Scale."
              action={<Button onClick={() => setShowAdd(true)}>Start a project</Button>} />
          )}
          {projects.map((p) => (
            <Card key={p.id} onClick={() => setOpenId(p.id)} style={{ padding: 16, cursor: "pointer" }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                <span style={{ fontSize: 15, fontWeight: 700 }}>{p.name}</span>
                <span style={{ fontSize: 11, fontWeight: 700, color: stageColor(p.stage), background: `${stageColor(p.stage)}22`, padding: "3px 9px", borderRadius: 999, height: "fit-content" }}>{p.stage}</span>
              </div>
              {p.description && <div style={{ fontSize: 12.5, color: C.textDim, marginBottom: 12, lineHeight: 1.5 }}>{p.description}</div>}
              <ProgressBar value={p.progress} color={stageColor(p.stage)} />
              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
                <span style={{ fontSize: 11, color: C.textFaint }}>{p.progress}% complete</span>
                <span style={{ fontSize: 11, color: C.textFaint }}>{p.status}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
      {showAdd && <AddProjectModal onClose={() => setShowAdd(false)} onAdd={(d) => { addProject(d); setShowAdd(false); }} />}
      {open && <ProjectDetailModal project={open} onClose={() => setOpenId(null)} onUpdate={(patch) => updateProject(open.id, patch)} onDelete={() => { deleteProject(open.id); setOpenId(null); }} />}
    </div>
  );
}

function AddProjectModal({ onClose, onAdd }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [problem, setProblem] = useState("");
  const [targetUsers, setTargetUsers] = useState("");
  return (
    <Modal title="New project" onClose={onClose} footer={
      <Button full disabled={!name.trim()} onClick={() => onAdd({ name: name.trim(), description: description.trim(), problem: problem.trim(), targetUsers: targetUsers.trim(), stage: "Idea" })}>Create project</Button>
    }>
      <Field label="Project name"><input style={inputStyle} placeholder="e.g. Freelance design service" value={name} onChange={(e) => setName(e.target.value)} autoFocus /></Field>
      <Field label="Description"><textarea style={{ ...inputStyle, minHeight: 60 }} value={description} onChange={(e) => setDescription(e.target.value)} /></Field>
      <Field label="What problem does it solve?"><textarea style={{ ...inputStyle, minHeight: 60 }} value={problem} onChange={(e) => setProblem(e.target.value)} /></Field>
      <Field label="Who is it for?"><input style={inputStyle} value={targetUsers} onChange={(e) => setTargetUsers(e.target.value)} placeholder="Target users" /></Field>
    </Modal>
  );
}

function ProjectDetailModal({ project, onClose, onUpdate, onDelete }) {
  const [newTask, setNewTask] = useState("");
  const [newLinkLabel, setNewLinkLabel] = useState("");
  const [newLinkUrl, setNewLinkUrl] = useState("");
  const addTask = () => { if (!newTask.trim()) return; onUpdate({ tasks: [...project.tasks, { id: uid(), label: newTask.trim(), done: false }] }); setNewTask(""); };
  const toggleTask = (id) => onUpdate({ tasks: project.tasks.map((t) => t.id === id ? { ...t, done: !t.done } : t) });
  const removeTask = (id) => onUpdate({ tasks: project.tasks.filter((t) => t.id !== id) });
  const addLink = () => { if (!newLinkUrl.trim()) return; onUpdate({ links: [...project.links, { id: uid(), label: newLinkLabel.trim() || newLinkUrl.trim(), url: newLinkUrl.trim() }] }); setNewLinkLabel(""); setNewLinkUrl(""); };

  return (
    <Modal title={project.name} onClose={onClose}>
      <Field label="Stage"><SegPicker options={PROJECT_STAGES} value={project.stage} onChange={(v) => onUpdate({ stage: v })} /></Field>
      <Field label="Status"><SegPicker options={PROJECT_STATUSES} value={project.status} onChange={(v) => onUpdate({ status: v })} /></Field>
      <Field label={`Progress — ${project.progress}%`}><input type="range" min={0} max={100} value={project.progress} onChange={(e) => onUpdate({ progress: Number(e.target.value) })} style={{ width: "100%" }} /></Field>
      <Field label="Deadline"><input type="date" style={inputStyle} value={project.deadline || ""} onChange={(e) => onUpdate({ deadline: e.target.value })} /></Field>

      <Field label="Problem"><textarea style={{ ...inputStyle, minHeight: 60 }} value={project.problem || ""} onChange={(e) => onUpdate({ problem: e.target.value })} /></Field>
      <Field label="Target users"><input style={inputStyle} value={project.targetUsers || ""} onChange={(e) => onUpdate({ targetUsers: e.target.value })} /></Field>
      <Field label="Solution"><textarea style={{ ...inputStyle, minHeight: 60 }} value={project.solution || ""} onChange={(e) => onUpdate({ solution: e.target.value })} /></Field>

      <div style={{ display: "flex", gap: 10 }}>
        <Field label="Revenue"><input type="number" style={inputStyle} value={project.revenue || 0} onChange={(e) => onUpdate({ revenue: Number(e.target.value) })} /></Field>
        <Field label="Expenses"><input type="number" style={inputStyle} value={project.expenses || 0} onChange={(e) => onUpdate({ expenses: Number(e.target.value) })} /></Field>
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>TASKS</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 10 }}>
          {project.tasks.map((t) => (
            <div key={t.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 11px", background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10 }}>
              <div onClick={() => toggleTask(t.id)} style={{ width: 18, height: 18, borderRadius: 5, border: `2px solid ${t.done ? C.accent : C.textFaint}`, background: t.done ? C.accent : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, cursor: "pointer" }}>
                {t.done && <Check size={11} color="#06120C" />}
              </div>
              <span style={{ flex: 1, fontSize: 12.5, textDecoration: t.done ? "line-through" : "none", color: t.done ? C.textFaint : C.text }}>{t.label}</span>
              <button onClick={() => removeTask(t.id)} style={{ background: "none", border: "none", color: C.textFaint }}><X size={13} /></button>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 6 }}>
          <input style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }} placeholder="Add a task…" value={newTask} onChange={(e) => setNewTask(e.target.value)} />
          <Button onClick={addTask} style={{ padding: "8px 12px" }}><Plus size={14} /></Button>
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 8 }}>LINKS</div>
        {project.links.map((l) => (
          <a key={l.id} href={l.url} target="_blank" rel="noreferrer" style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, color: C.blue, marginBottom: 6, textDecoration: "none" }}><Link2 size={12} /> {l.label}</a>
        ))}
        <div style={{ display: "flex", gap: 6, marginTop: 6 }}>
          <input style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }} placeholder="Label" value={newLinkLabel} onChange={(e) => setNewLinkLabel(e.target.value)} />
          <input style={{ ...inputStyle, flex: 1, padding: "8px 10px", fontSize: 12.5 }} placeholder="https://…" value={newLinkUrl} onChange={(e) => setNewLinkUrl(e.target.value)} />
          <Button onClick={addLink} style={{ padding: "8px 12px" }}><Plus size={14} /></Button>
        </div>
      </div>

      <Field label="Notes"><textarea style={{ ...inputStyle, minHeight: 70 }} value={project.notes || ""} onChange={(e) => onUpdate({ notes: e.target.value })} /></Field>

      <Button variant="danger" full onClick={onDelete}><Trash2 size={14} /> Delete project</Button>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- */
/* FOCUS MODE                                                              */
/* ---------------------------------------------------------------------- */
const FOCUS_PRESETS = [
  { id: "25-5", label: "25 / 5", work: 25, brk: 5 },
  { id: "50-10", label: "50 / 10", work: 50, brk: 10 },
  { id: "custom", label: "Custom", work: null, brk: null },
];

function FocusView({ missions, addFocusSession, setView }) {
  const [preset, setPreset] = useState("25-5");
  const [customWork, setCustomWork] = useState(30);
  const [customBreak, setCustomBreak] = useState(5);
  const [missionId, setMissionId] = useState("");
  const [phase, setPhase] = useState("setup"); // setup | work | break | logging
  const [secondsLeft, setSecondsLeft] = useState(0);
  const [running, setRunning] = useState(false);
  const [cycles, setCycles] = useState(0);
  const [result, setResult] = useState("");
  const startedAtRef = useRef(null);

  const openMissions = missions.filter((m) => !m.done);
  const activePreset = FOCUS_PRESETS.find((p) => p.id === preset);
  const workMin = preset === "custom" ? Number(customWork) || 1 : activePreset.work;
  const breakMin = preset === "custom" ? Number(customBreak) || 1 : activePreset.brk;
  const mission = openMissions.find((m) => m.id === missionId);

  useEffect(() => {
    if (!running) return;
    const iv = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          setRunning(false);
          if (phase === "work") setPhase("logging");
          else if (phase === "break") { setPhase("setup"); setCycles((c) => c + 1); }
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(iv);
  }, [running, phase]);

  const startWork = () => { startedAtRef.current = Date.now(); setPhase("work"); setSecondsLeft(workMin * 60); setRunning(true); };
  const startBreak = () => { setPhase("break"); setSecondsLeft(breakMin * 60); setRunning(true); };
  const endEarly = () => setPhase("logging");
  const saveSession = () => {
    addFocusSession({ mode: preset, workMinutes: workMin, missionId: missionId || null, missionTitle: mission?.title || null, result: result.trim(), completedAt: new Date().toISOString() });
    setResult(""); setPhase("setup");
  };

  if (phase === "work" || phase === "break") {
    const totalSec = (phase === "work" ? workMin : breakMin) * 60;
    return (
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 30, textAlign: "center" }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: 1, color: phase === "work" ? C.accent : C.blue, marginBottom: 14 }}>{phase === "work" ? "FOCUS SESSION" : "BREAK"}</div>
        {mission && phase === "work" && <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 22, maxWidth: 280 }}>{mission.title}</div>}
        <div className="font-display" style={{ fontSize: 64, fontWeight: 700, color: C.text, marginBottom: 20 }}>{mmss(secondsLeft)}</div>
        <div style={{ width: 220, marginBottom: 28 }}>
          <ProgressBar value={((totalSec - secondsLeft) / totalSec) * 100} color={phase === "work" ? C.accent : C.blue} height={6} />
        </div>
        <div style={{ fontSize: 12, color: C.textFaint, marginBottom: 30 }}>Cycle {cycles + 1}</div>
        <div style={{ display: "flex", gap: 10 }}>
          <Button variant="secondary" onClick={() => setRunning((r) => !r)}>{running ? <Pause size={15} /> : <Play size={15} />} {running ? "Pause" : "Resume"}</Button>
          <Button variant="ghost" onClick={endEarly}>End & log</Button>
        </div>
      </div>
    );
  }

  if (phase === "logging") {
    return (
      <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", justifyContent: "center", padding: 28 }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: C.accent, letterSpacing: 0.5, marginBottom: 8 }}>SESSION COMPLETE</div>
        <h2 className="font-display" style={{ fontSize: 21, fontWeight: 700, margin: "0 0 18px" }}>What did you accomplish?</h2>
        {mission && <div style={{ fontSize: 13, color: C.textDim, marginBottom: 14 }}>Mission: {mission.title}</div>}
        <textarea style={{ ...inputStyle, minHeight: 100 }} autoFocus value={result} onChange={(e) => setResult(e.target.value)} placeholder="Be specific — this is your own record, not a performance for anyone." />
        <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
          <Button variant="secondary" style={{ flex: 1 }} onClick={() => { setResult(""); setPhase("setup"); }}>Discard</Button>
          <Button style={{ flex: 1 }} disabled={!result.trim()} onClick={saveSession}>Save session</Button>
        </div>
        <Button variant="ghost" full style={{ marginTop: 10 }} onClick={startBreak}>Save & take a {breakMin}-min break</Button>
      </div>
    );
  }

  return (
    <div>
      <Header title="Focus Mode" onBack={() => setView("home")} />
      <div style={{ padding: "8px 20px" }}>
        <Field label="Session length">
          <SegPicker options={FOCUS_PRESETS} value={preset} onChange={setPreset} getKey={(p) => p.id} getLabel={(p) => p.label} />
        </Field>
        {preset === "custom" && (
          <div style={{ display: "flex", gap: 10 }}>
            <Field label="Work (min)"><input type="number" style={inputStyle} value={customWork} onChange={(e) => setCustomWork(e.target.value)} /></Field>
            <Field label="Break (min)"><input type="number" style={inputStyle} value={customBreak} onChange={(e) => setCustomBreak(e.target.value)} /></Field>
          </div>
        )}
        {openMissions.length > 0 && (
          <Field label="Attach to a mission (optional)">
            <SegPicker options={["", ...openMissions.map((m) => m.id)]} value={missionId} onChange={setMissionId} getLabel={(k) => k === "" ? "None" : openMissions.find((m) => m.id === k)?.title} />
          </Field>
        )}
        <Card style={{ marginBottom: 18, marginTop: 6 }}>
          <div style={{ fontSize: 12.5, color: C.textDim, lineHeight: 1.6 }}>{workMin} minutes of focused work, then a {breakMin}-minute break. Minimal UI during the session — just the timer and your mission.</div>
        </Card>
        <Button full onClick={startWork}><Play size={15} /> Start focus session</Button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* PROFILE                                                                 */
/* ---------------------------------------------------------------------- */
function ProfileView({ profile, skills, projects, finance, missions, setProfile, setView }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(profile.name);
  const level = levelFromXp(profile.xp);
  const unlocked = profile.achievementsUnlocked || {};
  const unlockedCount = ACHIEVEMENTS.filter((a) => unlocked[a.id]).length;

  const MENU = [
    { id: "focus", label: "Focus Mode", icon: Target },
    { id: "mentor", label: "AI Mentor", icon: MessageCircle },
    { id: "lab", label: "Opportunity Lab", icon: Lightbulb },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "finance", label: "Finance", icon: Wallet },
    { id: "review", label: "Weekly Review", icon: CalendarCheck },
    { id: "settings", label: "Settings", icon: SettingsIcon },
    { id: "subscription", label: "Subscription", icon: Crown },
  ];

  return (
    <div>
      <Header title="Profile" />
      <div style={{ padding: "8px 20px" }}>
        <Card style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <div className="font-display" style={{ width: 56, height: 56, borderRadius: 16, background: C.accentSoft, color: C.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22, fontWeight: 700, flexShrink: 0 }}>{profile.name.slice(0, 1).toUpperCase()}</div>
          <div style={{ flex: 1, minWidth: 0 }}>
            {editing ? (
              <div style={{ display: "flex", gap: 6 }}>
                <input style={{ ...inputStyle, padding: "7px 10px", fontSize: 14 }} value={name} onChange={(e) => setName(e.target.value)} autoFocus />
                <Button style={{ padding: "7px 12px" }} onClick={() => { setProfile((p) => ({ ...p, name: name.trim() || p.name })); setEditing(false); }}><Check size={14} /></Button>
              </div>
            ) : (
              <div style={{ display: "flex", alignItems: "center", gap: 8 }} onClick={() => setEditing(true)}>
                <div style={{ fontSize: 17, fontWeight: 700 }}>{profile.name}</div>
                <span style={{ fontSize: 11, color: C.textFaint }}>edit</span>
              </div>
            )}
            <div style={{ fontSize: 12.5, color: C.textDim, marginTop: 3 }}>Level {level} · {profile.xp} total XP</div>
            {profile.mainGoal && <div style={{ fontSize: 11.5, color: C.accent, marginTop: 3, fontWeight: 600 }}>{profile.mainGoal}</div>}
          </div>
        </Card>

        <div style={{ display: "flex", gap: 10, marginTop: 12 }}>
          <StatBox label="Skills" value={skills.length} icon={Sparkles} color={C.blue} />
          <StatBox label="Missions" value={profile.missionsCompleted} icon={Target} color={C.accent} />
          <StatBox label="Streak" value={profile.streak} icon={Flame} color={C.amber} />
        </div>

        <div style={{ marginTop: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.textFaint, marginBottom: 10 }}>ACHIEVEMENTS · {unlockedCount}/{ACHIEVEMENTS.length}</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            {ACHIEVEMENTS.map((a) => {
              const done = !!unlocked[a.id];
              const Icon = a.icon;
              return (
                <Card key={a.id} style={{ padding: 12, opacity: done ? 1 : 0.45 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 9, background: done ? C.accentSoft : C.surfaceHi, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 8 }}>
                    {done ? <Icon size={14} color={C.accent} /> : <Lock size={13} color={C.textFaint} />}
                  </div>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 3 }}>{a.label}</div>
                  <div style={{ fontSize: 10.5, color: C.textFaint, lineHeight: 1.4 }}>{a.description}</div>
                </Card>
              );
            })}
          </div>
        </div>

        <div style={{ marginTop: 20, display: "flex", flexDirection: "column", borderRadius: 16, overflow: "hidden", border: `1px solid ${C.border}` }}>
          {MENU.map((m, i) => {
            const Icon = m.icon;
            return (
              <button key={m.id} onClick={() => setView(m.id)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 16px", background: C.surface, border: "none", borderTop: i === 0 ? "none" : `1px solid ${C.borderSoft}`, cursor: "pointer", textAlign: "left" }}>
                <Icon size={17} color={C.textDim} />
                <span style={{ flex: 1, fontSize: 14, fontWeight: 500, color: C.text }}>{m.label}</span>
                <ChevronRight size={16} color={C.textFaint} />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* AI MENTOR                                                               */
/* ---------------------------------------------------------------------- */
function MentorView({ profile, skills, missions, projects, reviews, focusSessions, setView }) {
  const [messages, setMessages] = useState([
    { role: "assistant", content: `Hey ${profile.name}. I'm your mentor inside VALUE OS — I know your goal, skills, missions, projects, and past reviews. Ask me what to focus on, how to get unstuck, or challenge me on a decision — I'll push back if I think you're wrong.` },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    const next = [...messages, { role: "user", content: text }];
    setMessages(next); setInput(""); setLoading(true);
    const lastReview = reviews[0];
    const executionRatio = missions.length ? Math.round((missions.filter(m => m.done).length / missions.length) * 100) : null;
    const system = `You are the AI Mentor inside VALUE OS, an app that helps people build real skills and value through Learn -> Build -> Solve -> Sell -> Reinvest -> Scale. Be direct, practical, and encouraging without hype — never promise guaranteed wealth or "get rich quick" outcomes. Give specific, actionable next steps grounded in the user's actual data below.

Do not just agree with the user. If their plan is vague, their idea is weak, their excuse doesn't hold up, or their execution ratio is low relative to what they claim, say so plainly and explain why — a good mentor challenges when necessary instead of always validating. You can handle requests like: how to improve a specific skill area, what to build next, why progress has stalled, a 30-day plan, reviewing or validating a business idea, or teaching a concept directly. Keep responses under 150 words unless asked for more detail.

User's state:
- Goal: ${profile.mainGoal || "not set"}. Current priority: ${profile.roadmap?.currentPriority || "not set"}
- Level ${levelFromXp(profile.xp)}, ${profile.xp} total XP, ${profile.streak}-day streak, execution ratio ${executionRatio ?? "n/a"}%
- Skills: ${skills.map(s => `${s.name} (Lv${levelFromXp(s.xp)})`).join(", ") || "none tracked yet"}
- Open missions: ${missions.filter(m => !m.done).map(m => m.title).join("; ") || "none"}
- Projects: ${projects.map(p => `${p.name} (${p.stage}, ${p.progress}%)`).join("; ") || "none yet"}
- Focus sessions logged: ${focusSessions.length}
- Most recent review: ${lastReview ? (lastReview.kind === "ai" ? `Weaknesses: ${lastReview.weaknesses || "n/a"}. Next week priority: ${lastReview.nextWeek || "n/a"}` : `Challenges: ${lastReview.challenges || "n/a"}. Next focus: ${lastReview.nextFocus || "n/a"}`) : "none yet"}`;
    try {
      const reply = await askClaude(system, next.map(m => ({ role: m.role, content: m.content })));
      setMessages((m) => [...m, { role: "assistant", content: reply || "I couldn't generate a reply just now — try asking again." }]);
    } catch (e) { setMessages((m) => [...m, { role: "assistant", content: "Something went wrong reaching the mentor. Please try again." }]); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 90px)" }}>
      <Header title="AI Mentor" onBack={() => setView("home")} />
      <div style={{ flex: 1, overflowY: "auto", padding: "8px 20px" }}>
        {messages.map((m, i) => (
          <div key={i} className="rise" style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", marginBottom: 10 }}>
            <div style={{ maxWidth: "82%", padding: "10px 14px", borderRadius: 16, borderBottomRightRadius: m.role === "user" ? 4 : 16, borderBottomLeftRadius: m.role === "user" ? 16 : 4, background: m.role === "user" ? C.accent : C.surface, color: m.role === "user" ? "#06120C" : C.text, fontSize: 13.5, lineHeight: 1.55, border: m.role === "user" ? "none" : `1px solid ${C.border}` }}>{m.content}</div>
          </div>
        ))}
        {loading && <div style={{ display: "flex", gap: 6, alignItems: "center", color: C.textDim, fontSize: 12.5, padding: "4px 0" }}><Loader2 size={13} style={{ animation: "spin 1s linear infinite" }} /> thinking…</div>}
        <div ref={endRef} />
      </div>
      <div style={{ padding: "10px 20px 18px", display: "flex", gap: 8, borderTop: `1px solid ${C.borderSoft}` }}>
        <input style={{ ...inputStyle, flex: 1 }} placeholder="Ask your mentor anything…" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} />
        <button onClick={send} disabled={loading} style={{ background: C.accent, border: "none", borderRadius: 11, width: 44, display: "flex", alignItems: "center", justifyContent: "center", opacity: loading ? 0.6 : 1 }}><Send size={16} color="#06120C" /></button>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* OPPORTUNITY LAB                                                         */
/* ---------------------------------------------------------------------- */
function OpportunityLabView({ skills, addProject, flash, setView }) {
  const [skillsText, setSkillsText] = useState(skills.map((s) => s.name).join(", "));
  const [timeText, setTimeText] = useState("");
  const [fieldText, setFieldText] = useState("");
  const [loading, setLoading] = useState(false);
  const [ideas, setIdeas] = useState(null);
  const [error, setError] = useState(null);

  const generate = async () => {
    setLoading(true); setError(null); setIdeas(null);
    const system = `You are the Opportunity Lab inside VALUE OS, a tool that turns someone's skills, time, and interests into grounded, realistic value-creation opportunities. Rules: never claim or imply guaranteed income; never fabricate market statistics or numbers; if you rely on an assumption, state it plainly in the "assumptions" field rather than presenting it as fact.

Respond ONLY with a raw JSON array (no markdown fences) of exactly 3 objects with keys:
"title", "valueStage" (one of learn|build|solve|sell|reinvest|scale), "problem" (the real problem), "targetCustomer", "whyItMatters" (why this problem matters to that customer), "solution" (a possible solution), "requiredSkills" (array of strings), "difficulty" ("Beginner"|"Intermediate"|"Advanced"), "mvpComplexity" ("Low"|"Medium"|"High"), "monetization" (array of possible monetization approaches — described as possibilities, not projections), "validationPlan" (how to test demand before building much), "firstActions" (array of exactly 3 concrete actions to take this week), "assumptions" (string naming what is assumed/unverified in this idea).`;
    const user = `Skills: ${skillsText || "not specified"}\nAvailable time: ${timeText || "not specified"}\nField/industry of interest: ${fieldText || "not specified"}`;
    try {
      const raw = await askClaude(system, [{ role: "user", content: user }]);
      const parsed = parseJsonLoose(raw, null);
      if (Array.isArray(parsed)) setIdeas(parsed); else setError("Couldn't parse ideas — try again.");
    } catch (e) { setError("Couldn't generate ideas right now. Try again in a moment."); }
    finally { setLoading(false); }
  };

  return (
    <div>
      <Header title="Opportunity Lab" onBack={() => setView("home")} />
      <div style={{ padding: "8px 20px" }}>
        <p style={{ fontSize: 12.5, color: C.textDim, lineHeight: 1.6, marginTop: 0 }}>
          AI-generated ideas to explore, not guarantees. Every idea should be validated before you invest real time or money.
        </p>
        <Field label="I have these skills…"><textarea style={{ ...inputStyle, minHeight: 55 }} value={skillsText} onChange={(e) => setSkillsText(e.target.value)} placeholder="e.g. writing, spreadsheets, design" /></Field>
        <Field label="I have this amount of time…"><input style={inputStyle} value={timeText} onChange={(e) => setTimeText(e.target.value)} placeholder="e.g. 5 hours a week" /></Field>
        <Field label="I want to work in this field…"><input style={inputStyle} value={fieldText} onChange={(e) => setFieldText(e.target.value)} placeholder="e.g. education, local services, software" /></Field>
        <Button full onClick={generate} disabled={loading}>
          {loading ? <Loader2 size={15} style={{ animation: "spin 1s linear infinite" }} /> : <Sparkles size={15} />} {loading ? "Generating…" : "Discover opportunities"}
        </Button>
        {error && <div style={{ marginTop: 16, color: C.rose, fontSize: 13 }}>{error}</div>}

        <div style={{ marginTop: 18, display: "flex", flexDirection: "column", gap: 12 }}>
          {ideas && ideas.map((idea, i) => (
            <Card key={i} className="rise">
              <Tag label={pillarOf(idea.valueStage || "build").label} color={pillarOf(idea.valueStage || "build").color} />
              <div style={{ fontSize: 15, fontWeight: 700, margin: "8px 0 10px" }}>{idea.title}</div>

              <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Problem:</strong> <span style={{ color: C.textDim }}>{idea.problem}</span></div>
              <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Target customer:</strong> <span style={{ color: C.textDim }}>{idea.targetCustomer}</span></div>
              <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Why it matters:</strong> <span style={{ color: C.textDim }}>{idea.whyItMatters}</span></div>
              <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Possible solution:</strong> <span style={{ color: C.textDim }}>{idea.solution}</span></div>

              <div style={{ display: "flex", flexWrap: "wrap", gap: 10, margin: "10px 0" }}>
                <span style={{ fontSize: 11, color: C.textFaint }}>Difficulty: <strong style={{ color: C.text }}>{idea.difficulty}</strong></span>
                <span style={{ fontSize: 11, color: C.textFaint }}>MVP complexity: <strong style={{ color: C.text }}>{idea.mvpComplexity}</strong></span>
              </div>

              {idea.requiredSkills?.length > 0 && <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Required skills:</strong> <span style={{ color: C.textDim }}>{idea.requiredSkills.join(", ")}</span></div>}
              {idea.monetization?.length > 0 && <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Monetization possibilities:</strong> <span style={{ color: C.textDim }}>{idea.monetization.join(", ")}</span></div>}
              <div style={{ fontSize: 12, marginBottom: 8 }}><strong style={{ color: C.textFaint }}>Validation plan:</strong> <span style={{ color: C.textDim }}>{idea.validationPlan}</span></div>

              {idea.firstActions?.length > 0 && (
                <div style={{ marginBottom: 10 }}>
                  <strong style={{ fontSize: 12, color: C.textFaint }}>First 3 actions:</strong>
                  {idea.firstActions.map((a, j) => <div key={j} style={{ fontSize: 12, color: C.text, marginTop: 4 }}>{j + 1}. {a}</div>)}
                </div>
              )}

              {idea.assumptions && (
                <div style={{ display: "flex", gap: 6, fontSize: 11, color: C.amber, background: C.amberSoft, padding: "8px 10px", borderRadius: 9, marginBottom: 10 }}>
                  <AlertTriangle size={13} style={{ flexShrink: 0, marginTop: 1 }} /> <span><strong>Assumption:</strong> {idea.assumptions}</span>
                </div>
              )}

              <Button variant="secondary" style={{ padding: "8px 14px", fontSize: 12.5 }} onClick={() => {
                addProject({
                  name: idea.title, description: idea.solution, problem: idea.problem, targetUsers: idea.targetCustomer,
                  solution: idea.solution, stage: "Idea",
                  notes: `Required skills: ${(idea.requiredSkills || []).join(", ")}\nMonetization: ${(idea.monetization || []).join(", ")}\nValidation plan: ${idea.validationPlan}\nAssumptions: ${idea.assumptions}`,
                });
                flash("Added as project");
              }}>Add as project</Button>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* ANALYTICS                                                               */
/* ---------------------------------------------------------------------- */
function AnalyticsView({ missions, skills, projects, focusSessions, profile, setView }) {
  const [insights, setInsights] = useState(null);
  const [insightsBusy, setInsightsBusy] = useState(false);

  const categoryData = CATEGORIES.map((c) => ({ name: c.label, value: missions.filter((m) => m.category === c.id && m.done).length, color: c.color }));
  const days7 = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); return d.toISOString().slice(0, 10); });
  const days30 = [...Array(30)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (29 - i)); return d.toISOString().slice(0, 10); });
  const scoreByDay = days7.map((d) => ({ day: fmtDate(d), score: (profile.scoreHistory || []).find((h) => h.date === d)?.score ?? (d === todayStr() ? scoreForDate(missions, d) : 0) }));
  const monthlyTrend = days30.map((d) => ({ day: fmtDate(d), score: (profile.scoreHistory || []).find((h) => h.date === d)?.score ?? 0 }));

  const doneMissions = missions.filter((m) => m.done);
  const learningMin = doneMissions.filter((m) => m.category === "learning").reduce((s, m) => s + (m.estimatedMinutes || 0), 0);
  const buildingMin = doneMissions.filter((m) => m.category === "building").reduce((s, m) => s + (m.estimatedMinutes || 0), 0);
  const learningHours = (learningMin / 60).toFixed(1);
  const buildingHours = (buildingMin / 60).toFixed(1);

  const avgProjectProgress = projects.length ? Math.round(projects.reduce((s, p) => s + p.progress, 0) / projects.length) : 0;
  const focusMinutesTotal = focusSessions.reduce((s, f) => s + (f.workMinutes || 0), 0);
  const activeDays30 = new Set((profile.scoreHistory || []).filter((h) => h.score > 0 && days30.includes(h.date)).map((h) => h.date)).size;
  const consistency = Math.round((activeDays30 / 30) * 100);
  const executionRatio = missions.length ? Math.round((doneMissions.length / missions.length) * 100) : 0;

  const topSkills = skills.slice().sort((a, b) => b.xp - a.xp).slice(0, 4);

  const generateInsights = async () => {
    setInsightsBusy(true);
    const system = `You are the analytics engine inside VALUE OS. Look at the user's real activity data and give 2-4 short, honest, specific observations or suggestions — the kind a sharp mentor would give, not generic encouragement. Point out imbalances directly (e.g. too much learning vs building, low execution ratio, a neglected category). Respond ONLY with a raw JSON array of short strings (no markdown fences), each under 30 words.`;
    const user = `Learning hours: ${learningHours}, Building hours: ${buildingHours}\nExecution ratio (completed/total missions): ${executionRatio}%\nConsistency (active days out of last 30): ${consistency}%\nCurrent streak: ${profile.streak}\nAvg project progress: ${avgProjectProgress}%\nFocus sessions logged: ${focusSessions.length}, total focused minutes: ${focusMinutesTotal}\nCategory completion counts: ${categoryData.map((c) => `${c.name}: ${c.value}`).join(", ")}\nTop skills: ${topSkills.map((s) => `${s.name} (Lv${levelFromXp(s.xp)})`).join(", ") || "none"}`;
    try {
      const raw = await askClaude(system, [{ role: "user", content: user }]);
      const list = parseJsonLoose(raw, null);
      setInsights(Array.isArray(list) ? list : null);
    } catch (e) { setInsights(null); }
    finally { setInsightsBusy(false); }
  };

  return (
    <div>
      <Header title="Analytics" onBack={() => setView("home")} />
      <div style={{ padding: "8px 20px" }}>
        <div style={{ display: "flex", gap: 10, marginBottom: 12 }}>
          <StatBox label="Total XP" value={profile.xp} icon={TrendingUp} color={C.accent} />
          <StatBox label="Execution" value={`${executionRatio}%`} icon={Target} color={C.violet} />
          <StatBox label="Consistency" value={`${consistency}%`} icon={Flame} color={C.amber} />
        </div>
        <div style={{ display: "flex", gap: 10, marginBottom: 16 }}>
          <StatBox label="Learning hrs" value={learningHours} icon={BookOpen} color={C.blue} />
          <StatBox label="Building hrs" value={buildingHours} icon={FolderKanban} color={C.accent} />
          <StatBox label="Focus min" value={focusMinutesTotal} icon={ClipboardList} color={C.teal} />
        </div>

        <Card style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>AI Insights</div>
            <button onClick={generateInsights} disabled={insightsBusy} style={{ background: "none", border: "none", color: C.accent, fontSize: 11.5, fontWeight: 700, display: "flex", alignItems: "center", gap: 4 }}>
              {insightsBusy ? <Loader2 size={12} style={{ animation: "spin 1s linear infinite" }} /> : <Wand2 size={12} />} {insights ? "Refresh" : "Generate"}
            </button>
          </div>
          {!insights && !insightsBusy && <div style={{ fontSize: 12.5, color: C.textFaint }}>Honest, specific observations about your patterns — not generic encouragement.</div>}
          {insights && (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {insights.map((line, i) => <div key={i} style={{ fontSize: 12.5, color: C.text, lineHeight: 1.5, paddingLeft: 12, borderLeft: `2px solid ${C.accent}` }}>{line}</div>)}
            </div>
          )}
        </Card>

        <Card style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Value Score · last 7 days</div>
          <div style={{ height: 150 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scoreByDay}>
                <CartesianGrid stroke={C.borderSoft} vertical={false} />
                <XAxis dataKey="day" tick={{ fill: C.textFaint, fontSize: 10 }} axisLine={{ stroke: C.border }} tickLine={false} />
                <YAxis domain={[0, 100]} tick={{ fill: C.textFaint, fontSize: 10 }} axisLine={false} tickLine={false} width={26} />
                <Tooltip contentStyle={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 10, fontSize: 12 }} labelStyle={{ color: C.text }} />
                <Line type="monotone" dataKey="score" stroke={C.accent} strokeWidth={2.5} dot={{ r: 3, fill: C.accent }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Monthly trend · last 30 days</div>
          <div style={{ height: 130 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyTrend}>
                <XAxis dataKey="day" hide />
                <YAxis domain={[0, 100]} hide />
                <Tooltip contentStyle={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 10, fontSize: 12 }} labelStyle={{ color: C.text }} />
                <Line type="monotone" dataKey="score" stroke={C.violet} strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Missions completed by category</div>
          <div style={{ height: 200 }}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData}>
                <CartesianGrid stroke={C.borderSoft} vertical={false} />
                <XAxis dataKey="name" tick={{ fill: C.textFaint, fontSize: 8 }} axisLine={{ stroke: C.border }} tickLine={false} interval={0} angle={-30} textAnchor="end" height={60} />
                <YAxis allowDecimals={false} tick={{ fill: C.textFaint, fontSize: 10 }} axisLine={false} tickLine={false} width={22} />
                <Tooltip contentStyle={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 10, fontSize: 12 }} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>{categoryData.map((d, i) => <Cell key={i} fill={d.color} />)}</Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {topSkills.length > 0 && (
          <Card style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Skill progression</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {topSkills.map((s) => (
                <div key={s.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
                    <span>{s.name}</span><span style={{ color: C.textFaint }}>Lv{levelFromXp(s.xp)}</span>
                  </div>
                  <ProgressBar value={xpIntoLevel(s.xp)} color={groupOf(s.group).color} height={5} />
                </div>
              ))}
            </div>
          </Card>
        )}

        {projects.length > 0 && (
          <Card>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Project progress · avg {avgProjectProgress}%</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {projects.map((p) => (
                <div key={p.id}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
                    <span>{p.name}</span><span style={{ color: C.textFaint }}>{p.stage}</span>
                  </div>
                  <ProgressBar value={p.progress} color={stageColor(p.stage)} height={5} />
                </div>
              ))}
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* FINANCE                                                                 */
/* ---------------------------------------------------------------------- */
const FIN_TYPES = [
  { id: "income", label: "Income", color: C.accent },
  { id: "expense", label: "Expense", color: C.rose },
  { id: "reinvest", label: "Reinvested", color: C.violet },
  { id: "savings", label: "Savings", color: C.teal },
];
const EXPENSE_CATEGORIES = ["Housing", "Food", "Transport", "Subscriptions", "Education", "Business", "Health", "Other"];

function FinanceView({ finance, addFinance, deleteFinance, assets, addAsset, deleteAsset, setView }) {
  const [showAdd, setShowAdd] = useState(false);
  const [showAsset, setShowAsset] = useState(false);
  const totals = FIN_TYPES.reduce((acc, t) => { acc[t.id] = finance.filter((f) => f.type === t.id).reduce((s, f) => s + Number(f.amount), 0); return acc; }, {});
  const net = (totals.income || 0) - (totals.expense || 0);
  const savingsRate = totals.income ? Math.round((totals.savings / totals.income) * 100) : 0;
  const reinvestRate = totals.income ? Math.round((totals.reinvest / totals.income) * 100) : 0;

  const now = new Date();
  const monthIncome = finance.filter((f) => f.type === "income" && f.date.slice(0, 7) === now.toISOString().slice(0, 7)).reduce((s, f) => s + Number(f.amount), 0);
  const monthExpense = finance.filter((f) => f.type === "expense" && f.date.slice(0, 7) === now.toISOString().slice(0, 7)).reduce((s, f) => s + Number(f.amount), 0);
  const monthlyCashFlow = monthIncome - monthExpense;

  const totalAssets = assets.filter((a) => a.type === "asset").reduce((s, a) => s + Number(a.value), 0);
  const totalLiabilities = assets.filter((a) => a.type === "liability").reduce((s, a) => s + Number(a.value), 0);
  const netWorth = totalAssets - totalLiabilities;

  const expenseByCategory = EXPENSE_CATEGORIES.map((c) => ({ name: c, value: finance.filter((f) => f.type === "expense" && (f.category || "Other") === c).reduce((s, f) => s + Number(f.amount), 0) })).filter((c) => c.value > 0);

  return (
    <div>
      <Header title="Finance" onBack={() => setView("home")} right={
        <button onClick={() => setShowAdd(true)} style={{ background: C.accent, border: "none", borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center" }}><Plus size={18} color="#06120C" /></button>
      } />
      <div style={{ padding: "8px 20px" }}>
        <div style={{ fontSize: 11.5, color: C.textFaint, lineHeight: 1.5, marginBottom: 14, padding: "10px 12px", background: C.surfaceHi, borderRadius: 10 }}>
          Educational tracking only — this is not personalized financial advice, and nothing here projects or guarantees investment returns.
        </div>

        <Card style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, color: C.textDim, fontWeight: 600, marginBottom: 6 }}>NET WORTH (ASSETS − LIABILITIES)</div>
          <div className="font-display" style={{ fontSize: 30, fontWeight: 700, color: netWorth >= 0 ? C.accent : C.rose }}>{netWorth >= 0 ? "+" : ""}{netWorth.toLocaleString()}</div>
          <div style={{ display: "flex", gap: 16, marginTop: 10 }}>
            <span style={{ fontSize: 11.5, color: C.textDim }}>Assets: <strong style={{ color: C.text }}>{totalAssets.toLocaleString()}</strong></span>
            <span style={{ fontSize: 11.5, color: C.textDim }}>Liabilities: <strong style={{ color: C.text }}>{totalLiabilities.toLocaleString()}</strong></span>
          </div>
        </Card>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 12 }}>
          <StatBox label="Monthly cash flow" value={monthlyCashFlow.toLocaleString()} icon={monthlyCashFlow >= 0 ? TrendingUp : TrendingDown} color={monthlyCashFlow >= 0 ? C.accent : C.rose} />
          <StatBox label="All-time net" value={net.toLocaleString()} icon={Wallet} color={net >= 0 ? C.accent : C.rose} />
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
          <StatBox label="Savings rate" value={`${savingsRate}%`} icon={TrendingUp} color={C.teal} />
          <StatBox label="Reinvestment rate" value={`${reinvestRate}%`} icon={TrendingUp} color={C.violet} />
        </div>
        <div style={{ fontSize: 11, color: C.textFaint, lineHeight: 1.5, marginBottom: 16 }}>
          <strong style={{ color: C.textDim }}>Savings rate</strong> = savings ÷ income. <strong style={{ color: C.textDim }}>Reinvestment rate</strong> = reinvested ÷ income. Both are simple ratios of what you've logged, not predictions.
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 16 }}>
          {FIN_TYPES.map((t) => (
            <Card key={t.id} style={{ padding: 13 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: C.textDim, marginBottom: 6 }}>{t.label.toUpperCase()}</div>
              <div className="font-display" style={{ fontSize: 18, fontWeight: 700, color: t.color }}>{(totals[t.id] || 0).toLocaleString()}</div>
            </Card>
          ))}
        </div>

        {expenseByCategory.length > 0 && (
          <Card style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>Expenses by category</div>
            <div style={{ height: 160 }}>
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={expenseByCategory} layout="vertical">
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="name" tick={{ fill: C.textFaint, fontSize: 10 }} axisLine={false} tickLine={false} width={80} />
                  <Tooltip contentStyle={{ background: C.surfaceHi, border: `1px solid ${C.border}`, borderRadius: 10, fontSize: 12 }} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
                  <Bar dataKey="value" radius={[0, 6, 6, 0]} fill={C.rose} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        )}

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 700 }}>Assets & liabilities</div>
          <button onClick={() => setShowAsset(true)} style={{ background: "none", border: "none", color: C.accent, fontSize: 12, fontWeight: 700 }}>+ Add</button>
        </div>
        {assets.length === 0 ? (
          <div style={{ fontSize: 12, color: C.textFaint, marginBottom: 16 }}>Nothing logged yet — cash, savings, investments, equipment (assets) or debts, loans (liabilities).</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8, marginBottom: 16 }}>
            {assets.map((a) => (
              <Card key={a.id} style={{ padding: 12, display: "flex", alignItems: "center", gap: 10 }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{a.name}</div>
                  <div style={{ fontSize: 11, color: C.textFaint }}>{a.type === "asset" ? "Asset" : "Liability"}</div>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: a.type === "asset" ? C.accent : C.rose }}>{Number(a.value).toLocaleString()}</div>
                <button onClick={() => deleteAsset(a.id)} style={{ background: "none", border: "none", color: C.textFaint }}><Trash2 size={14} /></button>
              </Card>
            ))}
          </div>
        )}

        <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>Cash flow entries</div>
        {finance.length === 0 ? (
          <EmptyState icon={Wallet} title="No entries yet" sub="Track income, expenses, savings and reinvestment to see how your effort turns into real value over time." action={<Button onClick={() => setShowAdd(true)}>Add an entry</Button>} />
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {finance.map((f) => {
              const t = FIN_TYPES.find((x) => x.id === f.type);
              return (
                <Card key={f.id} style={{ padding: 12, display: "flex", alignItems: "center", gap: 10 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 9, background: `${t.color}22`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    {f.type === "expense" ? <TrendingDown size={14} color={t.color} /> : <TrendingUp size={14} color={t.color} />}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600 }}>{f.note || t.label}</div>
                    <div style={{ fontSize: 11, color: C.textFaint }}>{fmtDate(f.date)}{f.category ? ` · ${f.category}` : ""}</div>
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: t.color }}>{Number(f.amount).toLocaleString()}</div>
                  <button onClick={() => deleteFinance(f.id)} style={{ background: "none", border: "none", color: C.textFaint }}><Trash2 size={14} /></button>
                </Card>
              );
            })}
          </div>
        )}
      </div>
      {showAdd && <AddFinanceModal onClose={() => setShowAdd(false)} onAdd={(d) => { addFinance(d); setShowAdd(false); }} />}
      {showAsset && <AddAssetModal onClose={() => setShowAsset(false)} onAdd={(d) => { addAsset(d); setShowAsset(false); }} />}
    </div>
  );
}

function AddFinanceModal({ onClose, onAdd }) {
  const [type, setType] = useState("income");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [category, setCategory] = useState(EXPENSE_CATEGORIES[0]);
  return (
    <Modal title="New entry" onClose={onClose} footer={<Button full disabled={!amount || Number(amount) <= 0} onClick={() => onAdd({ type, amount: Number(amount), note: note.trim(), category: type === "expense" ? category : undefined })}>Save entry</Button>}>
      <Field label="Type"><SegPicker options={FIN_TYPES} value={type} onChange={setType} getKey={(t) => t.id} getLabel={(t) => t.label} /></Field>
      <Field label="Amount"><input style={inputStyle} type="number" inputMode="decimal" placeholder="0" value={amount} onChange={(e) => setAmount(e.target.value)} /></Field>
      {type === "expense" && <Field label="Category"><SegPicker options={EXPENSE_CATEGORIES} value={category} onChange={setCategory} /></Field>}
      <Field label="Note (optional)"><input style={inputStyle} placeholder="e.g. Freelance payment" value={note} onChange={(e) => setNote(e.target.value)} /></Field>
    </Modal>
  );
}

function AddAssetModal({ onClose, onAdd }) {
  const [type, setType] = useState("asset");
  const [name, setName] = useState("");
  const [value, setValue] = useState("");
  return (
    <Modal title="Add asset or liability" onClose={onClose} footer={<Button full disabled={!name.trim() || !value} onClick={() => onAdd({ type, name: name.trim(), value: Number(value) })}>Save</Button>}>
      <Field label="Type"><SegPicker options={[{ id: "asset", label: "Asset" }, { id: "liability", label: "Liability" }]} value={type} onChange={setType} getKey={(t) => t.id} getLabel={(t) => t.label} /></Field>
      <Field label="Name"><input style={inputStyle} placeholder="e.g. Savings account, Student loan" value={name} onChange={(e) => setName(e.target.value)} /></Field>
      <Field label="Current value"><input style={inputStyle} type="number" inputMode="decimal" placeholder="0" value={value} onChange={(e) => setValue(e.target.value)} /></Field>
    </Modal>
  );
}

/* ---------------------------------------------------------------------- */
/* WEEKLY REVIEW                                                           */
/* ---------------------------------------------------------------------- */
const CEO_SECTIONS = [
  { key: "wins", label: "Wins", sub: "What went well?" },
  { key: "weaknesses", label: "Weaknesses", sub: "What repeatedly failed?" },
  { key: "timeAllocation", label: "Time Allocation", sub: "Where did the time actually go?" },
  { key: "execution", label: "Execution", sub: "How much was actually completed?" },
  { key: "skillsSection", label: "Skills", sub: "Which skills improved?" },
  { key: "projectsSection", label: "Projects", sub: "What moved forward?" },
  { key: "nextWeek", label: "Next Week", sub: "What should be prioritized?" },
];

function WeeklyReviewView({ reviews, addReview, profile, missions, skills, projects, focusSessions, setView }) {
  const [wins, setWins] = useState("");
  const [challenges, setChallenges] = useState("");
  const [nextFocus, setNextFocus] = useState("");
  const [rating, setRating] = useState(7);
  const [ceoBusy, setCeoBusy] = useState(false);
  const submit = () => { if (!wins.trim() && !challenges.trim() && !nextFocus.trim()) return; addReview({ kind: "manual", wins: wins.trim(), challenges: challenges.trim(), nextFocus: nextFocus.trim(), rating }); setWins(""); setChallenges(""); setNextFocus(""); setRating(7); };

  const generateCeoReview = async () => {
    setCeoBusy(true);
    const days7 = [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - (6 - i)); return d.toISOString().slice(0, 10); });
    const weekMissions = missions.filter((m) => days7.includes(m.date));
    const doneWeek = weekMissions.filter((m) => m.done);
    const system = `You are the Weekly CEO Review generator inside VALUE OS. Be honest and constructive — never use fake motivational language ("You're crushing it!"). State plainly what worked, what didn't, and what to fix. Respond ONLY with raw JSON (no markdown fences), an object with keys: "wins", "weaknesses", "timeAllocation", "execution", "skillsSection", "projectsSection", "nextWeek" — each a short paragraph (2-4 sentences), direct and specific to the data given.`;
    const user = `This week: ${weekMissions.length} missions planned, ${doneWeek.length} completed (${weekMissions.length ? Math.round((doneWeek.length / weekMissions.length) * 100) : 0}% execution).
Category breakdown (completed): ${CATEGORIES.map((c) => `${c.label}: ${doneWeek.filter((m) => m.category === c.id).length}`).join(", ")}
Current streak: ${profile.streak} days
Skills: ${skills.map((s) => `${s.name} (Lv${levelFromXp(s.xp)}, ${s.xp}xp)`).join(", ") || "none tracked"}
Projects: ${projects.map((p) => `${p.name} (${p.stage}, ${p.progress}%)`).join("; ") || "none"}
Focus sessions this week: ${focusSessions.filter((f) => days7.includes(f.date)).length}
Missed missions this week: ${weekMissions.filter((m) => !m.done).map((m) => m.title).join("; ") || "none"}`;
    try {
      const raw = await askClaude(system, [{ role: "user", content: user }]);
      const parsed = parseJsonLoose(raw, null);
      if (parsed) addReview({ kind: "ai", rating: null, ...parsed });
    } catch (e) { /* silent, button just stays available to retry */ }
    finally { setCeoBusy(false); }
  };

  return (
    <div>
      <Header title="Weekly Review" onBack={() => setView("home")} />
      <div style={{ padding: "8px 20px" }}>
        <Card style={{ marginBottom: 14, borderColor: "rgba(74,222,158,0.3)" }}>
          <div style={{ fontSize: 13.5, fontWeight: 700, marginBottom: 6 }}>Weekly CEO Review</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginBottom: 12, lineHeight: 1.5 }}>An honest, structured review generated from your actual week — no fake motivational language.</div>
          <Button full onClick={generateCeoReview} disabled={ceoBusy}>
            {ceoBusy ? <Loader2 size={15} style={{ animation: "spin 1s linear infinite" }} /> : <Wand2 size={15} />} {ceoBusy ? "Reviewing…" : "Generate this week's review"}
          </Button>
        </Card>

        <Card style={{ marginBottom: 18 }}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 10 }}>Or write your own</div>
          <Field label="What went well this week?"><textarea style={{ ...inputStyle, minHeight: 60 }} value={wins} onChange={(e) => setWins(e.target.value)} /></Field>
          <Field label="What got in the way?"><textarea style={{ ...inputStyle, minHeight: 60 }} value={challenges} onChange={(e) => setChallenges(e.target.value)} /></Field>
          <Field label="What's the one focus for next week?"><textarea style={{ ...inputStyle, minHeight: 50 }} value={nextFocus} onChange={(e) => setNextFocus(e.target.value)} /></Field>
          <Field label={`Self-rating this week — ${rating}/10`}><input type="range" min={1} max={10} value={rating} onChange={(e) => setRating(Number(e.target.value))} style={{ width: "100%" }} /></Field>
          <Button full onClick={submit}>Save review</Button>
        </Card>

        {reviews.length === 0 ? (
          <EmptyState icon={CalendarCheck} title="No reviews yet" sub="A short weekly reflection compounds fast — it turns busy weeks into real progress." />
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {reviews.map((r) => (
              <Card key={r.id}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
                  <span style={{ fontSize: 12, color: C.textFaint }}>{fmtDate(r.date)} {r.kind === "ai" && <Tag label="AI CEO Review" color={C.accent} />}</span>
                  {r.rating != null && <span style={{ fontSize: 12, fontWeight: 700, color: C.accent }}>{r.rating}/10</span>}
                </div>
                {r.kind === "ai" ? (
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {CEO_SECTIONS.map((s) => r[s.key] && (
                      <div key={s.key}>
                        <div style={{ fontSize: 11, fontWeight: 700, color: C.textFaint, marginBottom: 2 }}>{s.label.toUpperCase()}</div>
                        <div style={{ fontSize: 12.5, color: C.text, lineHeight: 1.5 }}>{r[s.key]}</div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <>
                    {r.wins && <div style={{ fontSize: 13, marginBottom: 6 }}><strong style={{ color: C.textDim }}>Wins:</strong> {r.wins}</div>}
                    {r.challenges && <div style={{ fontSize: 13, marginBottom: 6 }}><strong style={{ color: C.textDim }}>Challenges:</strong> {r.challenges}</div>}
                    {r.nextFocus && <div style={{ fontSize: 13 }}><strong style={{ color: C.textDim }}>Next:</strong> {r.nextFocus}</div>}
                  </>
                )}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* SETTINGS                                                                */
/* ---------------------------------------------------------------------- */
function SettingsView({ profile, skills, missions, projects, finance, assets, reviews, focusSessions, setProfile, resetAll, setView, logout }) {
  const [name, setName] = useState(profile.name);
  const [confirmReset, setConfirmReset] = useState(false);

  const exportData = () => {
    const payload = { profile, skills, missions, projects, finance, assets, reviews, focusSessions, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "value-os-data.json"; a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <Header title="Settings" onBack={() => setView("profile")} />
      <div style={{ padding: "8px 20px", display: "flex", flexDirection: "column", gap: 14 }}>
        <Card>
          <Field label="Your name">
            <div style={{ display: "flex", gap: 8 }}>
              <input style={inputStyle} value={name} onChange={(e) => setName(e.target.value)} />
              <Button onClick={() => setProfile((p) => ({ ...p, name: name.trim() || p.name }))}>Save</Button>
            </div>
          </Field>
        </Card>
        <Card>
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>Export your data</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginBottom: 12, lineHeight: 1.5 }}>Download everything you've tracked as a JSON file.</div>
          <Button variant="secondary" onClick={exportData}><Download size={14} /> Export as JSON</Button>
        </Card>
        <GetAppCard />
        <Card>
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 6 }}>Account</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginBottom: 12, lineHeight: 1.5 }}>Your data is saved to your account, not just this device.</div>
          <Button variant="secondary" onClick={logout}>Log out</Button>
        </Card>
        <Card style={{ borderColor: "rgba(240,112,138,0.3)" }}>
          <div style={{ fontSize: 13.5, fontWeight: 600, marginBottom: 6, color: C.rose }}>Danger zone</div>
          <div style={{ fontSize: 12.5, color: C.textDim, marginBottom: 12, lineHeight: 1.5 }}>Permanently clear all missions, skills, projects, finance entries, reviews and your onboarding profile.</div>
          {!confirmReset ? (
            <Button variant="danger" onClick={() => setConfirmReset(true)}><Trash2 size={14} /> Reset all data</Button>
          ) : (
            <div>
              <div style={{ display: "flex", gap: 8, alignItems: "center", color: C.rose, fontSize: 12.5, marginBottom: 10 }}><AlertTriangle size={14} /> This cannot be undone.</div>
              <div style={{ display: "flex", gap: 8 }}>
                <Button variant="secondary" onClick={() => setConfirmReset(false)} style={{ flex: 1 }}>Cancel</Button>
                <Button variant="danger" onClick={() => { resetAll(); setConfirmReset(false); }} style={{ flex: 1 }}>Confirm reset</Button>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

/* ---------------------------------------------------------------------- */
/* SUBSCRIPTION                                                            */
/* ---------------------------------------------------------------------- */
function SubscriptionView({ setView }) {
  const FREE = ["Unlimited missions, skills & projects", "AI Mentor & Opportunity Lab", "Analytics & Finance tracking", "Local, private data storage"];
  const PRO = ["Everything in Free", "Deeper AI mentor context & memory", "Advanced analytics & exports", "Priority feature access"];
  return (
    <div>
      <Header title="Subscription" onBack={() => setView("profile")} />
      <div style={{ padding: "8px 20px" }}>
        <Card style={{ marginBottom: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <span style={{ fontSize: 15, fontWeight: 700 }}>Free</span>
            <span style={{ fontSize: 11, fontWeight: 700, color: C.accent, background: C.accentSoft, padding: "4px 10px", borderRadius: 999 }}>CURRENT PLAN</span>
          </div>
          {FREE.map((f, i) => <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 13, color: C.textDim, marginBottom: 8 }}><Check size={14} color={C.accent} style={{ marginTop: 2, flexShrink: 0 }} /> {f}</div>)}
        </Card>
        <Card style={{ borderColor: "rgba(232,178,77,0.3)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}><Crown size={16} color={C.amber} /><span style={{ fontSize: 15, fontWeight: 700 }}>Pro</span></div>
          {PRO.map((f, i) => <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", fontSize: 13, color: C.textDim, marginBottom: 8 }}><Check size={14} color={C.amber} style={{ marginTop: 2, flexShrink: 0 }} /> {f}</div>)}
          <Button full disabled style={{ marginTop: 8, background: C.surfaceHi, color: C.textFaint }}>Coming soon</Button>
        </Card>
      </div>
    </div>
  );
}
