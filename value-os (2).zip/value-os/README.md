# Value OS

Build Skills. Create Value. Solve Problems. Build Assets.

## Status

- **Site:** value-os (Netlify) — public, no login wall on the site itself.
- **URL once deployed:** https://value-os.netlify.app
- **Dashboard:** https://app.netlify.com/projects/value-os
- **Database:** a real Postgres database (Netlify DB) is wired up. It
  provisions itself automatically on the first deploy — no manual setup.
- **Session secret:** `JWT_SECRET` is already set on the live site.
- **Still needed from you:** `ANTHROPIC_API_KEY` (for AI features) — add it
  in Site configuration → Environment variables before or after the first
  deploy.

The one remaining step to go live is connecting this code to the site via
GitHub (see "Finishing the deploy" below) — nothing else is blocking it.

## What's in this build

**Core:** onboarding → AI-generated Value Roadmap, a scored daily directive
engine, a skill tree (XP only from completed missions/practice tasks, never
from clicking a button), project lifecycle management (Idea → Problem →
Validation → MVP → Launch → Feedback → Iteration → Revenue → Scale), and an
Opportunity Lab that labels its own assumptions and never promises income.

**Also included:**
- **Value Score Engine** — a transparent 0–100 daily score, weighted by
  category (Building and Problem Solving count for more than passive
  categories), computed only from completed, meaningful work.
- **Focus Mode** — 25/5, 50/10, or custom work/break timers, with a
  post-session "what did you accomplish?" log.
- **Analytics** — value score trend, category breakdown, execution ratio,
  consistency, focus session stats, and on-demand AI insights.
- **Weekly CEO Review** — an AI-generated, deliberately unflattering review
  (wins / weaknesses / time allocation / execution / skills / projects /
  next week), plus a manual option.
- **Personal Finance module** — income, expenses, savings, reinvestment,
  assets and liabilities, net worth, savings/reinvestment rate, and expense
  categories. Educational, not personalized financial advice.
- **Anti-procrastination check-ins** — detects missions you planned but
  didn't finish and asks what blocked you, without shaming language.
- **Achievements** — a small, meaningful set (first mission, first project
  milestone, 7-day execution streak, first validation, first revenue,
  reaching skill level 5).

## Authentication & database (sections 19–20)

This is now backed by a real, normalized Postgres database instead of
localStorage:

- **Tables:** users, password_resets, profiles, goals, skills, user_skills,
  missions, mission_completions, focus_sessions, projects, project_tasks,
  opportunities, reviews, financial_records, achievements, notifications,
  subscriptions, ai_conversations, ai_usage — with foreign keys and indexes.
  See `netlify/database/migrations/20260919120000_init/migration.sql`.
- **Auth:** email/password signup, login, logout, and session checks, using
  bcrypt password hashing and a JWT stored in an HttpOnly cookie (not
  readable by JS, so it isn't a normal XSS target). All app data routes
  (`/api/state`, `/api/mentor`) require a valid session — that's the
  "protected routes" requirement.
- **What's fully wired end-to-end:** signup/login/logout/session, and
  syncing your profile, skills, missions, projects, finance, assets,
  reviews, and focus sessions to their normalized tables (including a real
  `mission_completions` history, not just a boolean).
- **What's schema-ready but not yet wired to the UI:** `goals` (history of
  goal changes), `opportunities` (saved Opportunity Lab results),
  `notifications`, `subscriptions`, `ai_conversations`/`ai_usage` (usage
  logging). The tables exist; nothing writes to them yet. Ask me to wire
  any of these up next.
- **localStorage's new role:** an offline cache only. The app reads from
  Postgres on load and writes to it on every change; if you're offline, it
  falls back to the last synced copy and shows an "Offline" banner, then
  syncs again once you're back.

### Two things I could not finish for you

1. **Google login.** This requires *your own* OAuth credentials from
   Google Cloud Console (an app registration only you can create for your
   own accounts/billing). Email/password auth is fully working now; if you
   want Google sign-in added, create the OAuth client and share the client
   ID, and I'll wire it in.
2. **Actually emailing password-reset links.** "Forgot password" creates a
   real, expiring reset token in the database — but nothing sends it,
   since no email service is connected. The next step is connecting an
   email provider (e.g. Resend or SendGrid); I can wire that up as soon as
   one is connected.

## Finishing the deploy — no computer required

### 1. Get an Anthropic API key (for AI Mentor / Opportunity Lab / Roadmap / CEO Review)
console.anthropic.com → API Keys → Create Key.

### 2. Put this code on GitHub
- github.com → sign in → **New repository** (e.g. `value-os`).
- **Add file → Upload files** → upload everything in this folder, keeping
  the structure (`src/`, `netlify/`, `public/`, plus the root files).
- Commit.

### 3. Connect the repo to the site
- **app.netlify.com/projects/value-os** → Site configuration → Build &
  deploy → Link repository → choose GitHub → select the `value-os` repo.
- Build command `npm run build`, publish directory `dist` (already set in
  `netlify.toml`).
- Before or right after the first deploy: Site configuration →
  Environment variables → add `ANTHROPIC_API_KEY`.
- The database migration applies automatically during the deploy.

Once that build finishes, **https://value-os.netlify.app** is live — open
it, sign up with an email and password, and it'll walk you into onboarding.

### 4. Install it on your phone
Open the URL → browser menu → **Add to Home Screen**.

## Getting a real Android .apk

I can't compile an .apk myself — that needs the Android SDK and a build
toolchain I don't have access to in this environment, and you're
phone-only anyway, so a local Android Studio build isn't realistic. The
right tool for your situation is **PWABuilder** (pwabuilder.com), Microsoft's
own tool for exactly this: it turns a live PWA URL into a real, signed,
installable Android app — entirely from a browser, no coding, no laptop.
It works by wrapping your site in a Trusted Web Activity (TWA), the same
technique apps like Twitter Lite and Starbucks used to ship to the Play
Store from their PWAs.

**This depends on step 3 above being done first** — PWABuilder needs your
app to be live at `https://value-os.netlify.app`, not just sitting in this
zip.

Once it's live:
1. On your phone, go to **pwabuilder.com**.
2. Enter `https://value-os.netlify.app` and let it analyze the site.
3. Go to the **Android** package option.
4. Choose to generate a **signed** package (not unsigned) — this saves you
   a manual signing step. Keep the generated keystore/credentials
   somewhere safe; you'll need the same one to release future updates.
5. Download the `.apk`. On Android, open the downloaded file to install it
   (you may need to allow "install unknown apps" for your browser once).

The manifest and icons in this project (`public/manifest.json`,
`icon-192.png`, `icon-512.png`) are already set up the way PWABuilder
expects, including a maskable icon.

### Letting other people download and keep it

Once the site is live, anyone can get the app from this link — no login
needed to see it, and you can send it to anyone:

**https://value-os.netlify.app/download.html**

It offers, depending on the person's phone:
- **Install app** — one tap on Android Chrome; adds Value OS to the home
  screen, opens full screen, and the interface works offline.
- **Download for Android (.apk)** — appears automatically once you add the
  file (below).
- **iPhone / iPad** — step-by-step "Add to Home Screen" instructions
  (iOS doesn't allow APK files; this is the only way there).

The same Install / Download / Share buttons are also inside the app, on the
login screen and under **Settings → Get the app** (with a "Share download
link" button that opens your phone's share sheet).

**To make the .apk download button appear:**
1. Generate the `.apk` with PWABuilder (steps above).
2. Rename it exactly `value-os.apk`.
3. Upload it to the `public/downloads/` folder of your GitHub repo
   (Add file → Upload files, inside that folder).
4. Let Netlify redeploy. The button shows up on its own, both on
   `/download.html` and inside the app. Until the file exists, the button
   stays hidden so nobody gets a broken download.

### Removing the browser address bar (optional polish)
By default the app opens with a thin address bar, since Android hasn't
verified you own the domain yet. To remove it:
1. After generating a **signed** package, PWABuilder shows you a SHA-256
   fingerprint for the signing key.
2. Use that fingerprint to fill in `public/.well-known/assetlinks.json`
   (currently an empty placeholder in this project) — PWABuilder's own
   "Removing the browser address bar" guide shows the exact JSON shape.
3. Re-upload that one file to your GitHub repo and let Netlify redeploy.

This step is cosmetic — the app installs and runs fully without it.

### If you later want a Play Store release or a repeatable CI build
That's a further step up (Play Console account, app bundle instead of
APK, a persistent signing key kept as a secret). PWABuilder can produce
the `.aab` for that too. I can also set up a GitHub Actions pipeline that
rebuilds the Android package automatically on every push using Bubblewrap
(the same tool PWABuilder uses under the hood) — I didn't build that here
because it needs a real Android SDK to actually execute and I have no way
to test it end-to-end from this environment, so it's better set up once
you're ready to invest in debugging it if something doesn't line up. Say
the word if you want me to draft it anyway.

## Local development (optional, needs a computer)

```bash
npm install
netlify dev
```

Use `netlify dev` (not plain `vite`) so the database and functions are
emulated locally.

## Notes

- The AI Mentor, Roadmap, and Opportunity Lab are explicitly instructed to
  never promise guaranteed income or outcomes, and to challenge you rather
  than just agree.
- **Settings → Export as JSON** still works as a personal backup on top of
  the database.
