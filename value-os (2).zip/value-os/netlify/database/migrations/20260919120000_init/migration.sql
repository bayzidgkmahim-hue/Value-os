-- Value OS — initial schema
-- Applied automatically by Netlify on deploy (see netlify/database/migrations).

CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE password_resets (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token TEXT UNIQUE NOT NULL,
  expires_at TIMESTAMP NOT NULL,
  used BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_password_resets_user ON password_resets(user_id);

CREATE TABLE profiles (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  name TEXT NOT NULL DEFAULT 'Builder',
  age_range TEXT,
  role TEXT,
  main_goal TEXT,
  long_term_vision TEXT,
  skill_level TEXT,
  daily_time TEXT,
  existing_skills TEXT,
  interests TEXT,
  learning_style TEXT,
  business_interests JSONB NOT NULL DEFAULT '[]',
  current_projects_text TEXT,
  biggest_obstacle TEXT,
  onboarded BOOLEAN NOT NULL DEFAULT FALSE,
  xp INTEGER NOT NULL DEFAULT 0,
  streak INTEGER NOT NULL DEFAULT 0,
  last_active_date DATE,
  missions_completed INTEGER NOT NULL DEFAULT 0,
  roadmap JSONB,
  score_history JSONB NOT NULL DEFAULT '[]',
  checkins JSONB NOT NULL DEFAULT '[]',
  updated_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Goal history — logs changes to main_goal over time.
CREATE TABLE goals (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  goal_text TEXT NOT NULL,
  set_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_goals_user ON goals(user_id);

-- Global skill catalog (deduplicated by name + group).
CREATE TABLE skills (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  group_name TEXT NOT NULL,
  subcategory TEXT,
  UNIQUE(name, group_name)
);

-- Per-user progress against a catalog skill.
CREATE TABLE user_skills (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  skill_id INTEGER NOT NULL REFERENCES skills(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  xp INTEGER NOT NULL DEFAULT 0,
  prerequisites JSONB NOT NULL DEFAULT '[]',
  resources JSONB NOT NULL DEFAULT '[]',
  practice_tasks JSONB NOT NULL DEFAULT '[]',
  linked_project_client_ids JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, skill_id)
);
CREATE INDEX idx_user_skills_user ON user_skills(user_id);

CREATE TABLE projects (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  problem TEXT,
  target_users TEXT,
  solution TEXT,
  stage TEXT NOT NULL DEFAULT 'Idea',
  status TEXT NOT NULL DEFAULT 'Active',
  progress INTEGER NOT NULL DEFAULT 0,
  deadline DATE,
  revenue NUMERIC NOT NULL DEFAULT 0,
  expenses NUMERIC NOT NULL DEFAULT 0,
  notes TEXT,
  links JSONB NOT NULL DEFAULT '[]',
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, client_id)
);
CREATE INDEX idx_projects_user ON projects(user_id);

CREATE TABLE project_tasks (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  label TEXT NOT NULL,
  done BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_project_tasks_project ON project_tasks(project_id);

CREATE TABLE missions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  difficulty TEXT NOT NULL,
  estimated_minutes INTEGER NOT NULL DEFAULT 0,
  recurring BOOLEAN NOT NULL DEFAULT FALSE,
  skill_client_id TEXT,
  priority TEXT,
  reason TEXT,
  mission_date DATE NOT NULL,
  done BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, client_id)
);
CREATE INDEX idx_missions_user_date ON missions(user_id, mission_date);

-- Log of individual completions, so a recurring mission keeps a real history
-- across days instead of a single boolean.
CREATE TABLE mission_completions (
  id SERIAL PRIMARY KEY,
  mission_id INTEGER NOT NULL REFERENCES missions(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  completed_date DATE NOT NULL,
  xp_awarded INTEGER NOT NULL,
  completed_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(mission_id, completed_date)
);
CREATE INDEX idx_mission_completions_user_date ON mission_completions(user_id, completed_date);

CREATE TABLE focus_sessions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  mission_client_id TEXT,
  mode TEXT,
  work_minutes INTEGER,
  result TEXT,
  completed_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, client_id)
);
CREATE INDEX idx_focus_sessions_user ON focus_sessions(user_id);

-- Opportunity Lab results the user chose to keep.
CREATE TABLE opportunities (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT,
  value_stage TEXT,
  problem TEXT,
  target_customer TEXT,
  why_it_matters TEXT,
  solution TEXT,
  required_skills JSONB NOT NULL DEFAULT '[]',
  difficulty TEXT,
  mvp_complexity TEXT,
  monetization JSONB NOT NULL DEFAULT '[]',
  validation_plan TEXT,
  first_actions JSONB NOT NULL DEFAULT '[]',
  assumptions TEXT,
  converted_to_project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_opportunities_user ON opportunities(user_id);

CREATE TABLE reviews (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'manual',
  review_date DATE NOT NULL,
  wins TEXT,
  weaknesses TEXT,
  time_allocation TEXT,
  execution TEXT,
  skills_section TEXT,
  projects_section TEXT,
  next_week TEXT,
  rating INTEGER,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, client_id)
);
CREATE INDEX idx_reviews_user ON reviews(user_id, review_date);

-- Covers income, expense, savings, reinvestment, assets and liabilities —
-- distinguished by `kind`.
CREATE TABLE financial_records (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  client_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  category TEXT,
  note TEXT,
  record_date DATE NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, client_id)
);
CREATE INDEX idx_financial_records_user ON financial_records(user_id, record_date);

CREATE TABLE achievements (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  achievement_key TEXT NOT NULL,
  unlocked_at TIMESTAMP NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, achievement_key)
);
CREATE INDEX idx_achievements_user ON achievements(user_id);

CREATE TABLE notifications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type TEXT,
  title TEXT,
  body TEXT,
  read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_notifications_user ON notifications(user_id, read);

CREATE TABLE subscriptions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  plan TEXT NOT NULL DEFAULT 'free',
  status TEXT NOT NULL DEFAULT 'active',
  started_at TIMESTAMP NOT NULL DEFAULT NOW(),
  renews_at TIMESTAMP
);

CREATE TABLE ai_conversations (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  context TEXT,
  role TEXT NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_conversations_user ON ai_conversations(user_id, created_at);

CREATE TABLE ai_usage (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  endpoint TEXT,
  input_tokens INTEGER,
  output_tokens INTEGER,
  created_at TIMESTAMP NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_ai_usage_user ON ai_usage(user_id, created_at);
