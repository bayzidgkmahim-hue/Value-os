// Netlify Function: POST { system, messages } -> { text }
// Keeps ANTHROPIC_API_KEY on the server. Set it in Site settings ->
// Environment variables before deploying (see README).
// Requires a logged-in session — this is a protected route like the rest of
// the app's data, and it also stops the API key from being usable by anyone
// who isn't signed in.
const { getUserId, json: authJson } = require("./_lib/auth.cjs");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method not allowed" }) };
  }
  const uid = getUserId(event);
  if (!uid) return authJson(401, { error: "Not authenticated." });
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: "ANTHROPIC_API_KEY is not set on the server." }) };
  }
  try {
    const { system, messages } = JSON.parse(event.body || "{}");
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({ model: "claude-sonnet-5", max_tokens: 1400, system, messages }),
    });
    const data = await r.json();
    if (!r.ok) {
      return { statusCode: r.status, body: JSON.stringify({ error: data?.error?.message || "Anthropic API error" }) };
    }
    const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
    return { statusCode: 200, body: JSON.stringify({ text }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: "AI request failed" }) };
  }
};
