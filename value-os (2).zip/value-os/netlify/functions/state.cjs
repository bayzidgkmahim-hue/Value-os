// Handles GET/PUT /api/state — this is what replaced localStorage as the
// primary store. GET reassembles the client's app-state shape from the
// normalized tables; PUT replace-syncs those tables from the client's
// current full state (the client already worked in "save whole array on
// change" terms, so this mirrors that instead of diffing incrementally).
const { getDatabase } = require("@netlify/database");
const { getUserId, json } = require("./_lib/auth.cjs");

const db = getDatabase();
const DIFF_XP = { easy: 10, medium: 25, hard: 50 };

function toDateStr(d) {
  if (!d) return null;
  if (typeof d === "string") return d.slice(0, 10);
  return d.toISOString().slice(0, 10);
}

async function loadState(uid) {
  const [profileRow] = await db.sql`
    SELECT
      name, age_range AS "ageRange", role, main_goal AS "mainGoal",
      long_term_vision AS "longTermVision", skill_level AS "skillLevel",
      daily_time AS "dailyTime", existing_skills AS "existingSkills",
      interests, learning_style AS "learningStyle",
      business_interests AS "businessInterests",
      current_projects_text AS "currentProjectsText",
      biggest_obstacle AS "biggestObstacle",
      onboarded, xp, streak,
      last_active_date AS "lastActiveDate",
      missions_completed AS "missionsCompleted",
      roadmap, score_history AS "scoreHistory", checkins
    FROM profiles WHERE user_id = ${uid}
  `;

  const achievementRows = await db.sql`SELECT achievement_key AS "key" FROM achievements WHERE user_id = ${uid}`;
  const achievementsUnlocked = {};
  achievementRows.forEach((r) => { achievementsUnlocked[r.key] = true; });

  const skills = await db.sql`
    SELECT us.client_id AS "id", s.name, s.group_name AS "group", s.subcategory,
           us.xp, us.prerequisites, us.resources,
           us.practice_tasks AS "practiceTasks",
           us.linked_project_client_ids AS "linkedProjectIds"
    FROM user_skills us JOIN skills s ON us.skill_id = s.id
    WHERE us.user_id = ${uid}
  `;

  const missionRows = await db.sql`
    SELECT client_id AS "id", title, category, difficulty,
           estimated_minutes AS "estimatedMinutes", recurring,
           skill_client_id AS "skillId", priority, reason,
           mission_date AS "date", done
    FROM missions WHERE user_id = ${uid} ORDER BY mission_date DESC
  `;
  const missions = missionRows.map((m) => ({ ...m, date: toDateStr(m.date) }));

  const projectRows = await db.sql`SELECT * FROM projects WHERE user_id = ${uid} ORDER BY created_at DESC`;
  const projects = [];
  for (const p of projectRows) {
    const tasks = await db.sql`SELECT client_id AS "id", label, done FROM project_tasks WHERE project_id = ${p.id}`;
    projects.push({
      id: p.client_id, name: p.name, description: p.description || "", problem: p.problem || "",
      targetUsers: p.target_users || "", solution: p.solution || "", stage: p.stage, status: p.status,
      progress: p.progress, deadline: toDateStr(p.deadline) || "",
      revenue: Number(p.revenue), expenses: Number(p.expenses), notes: p.notes || "",
      links: p.links || [], tasks, createdAt: toDateStr(p.created_at),
    });
  }

  const financeRows = await db.sql`
    SELECT client_id AS "id", kind AS "type", amount, category, note, record_date AS "date"
    FROM financial_records WHERE user_id = ${uid} AND kind IN ('income','expense','reinvest','savings')
    ORDER BY record_date DESC
  `;
  const finance = financeRows.map((f) => ({ ...f, amount: Number(f.amount), date: toDateStr(f.date) }));

  const assetRows = await db.sql`
    SELECT client_id AS "id", kind AS "type", amount AS "value", note AS "name", record_date AS "date"
    FROM financial_records WHERE user_id = ${uid} AND kind IN ('asset','liability')
    ORDER BY record_date DESC
  `;
  const assets = assetRows.map((a) => ({ ...a, value: Number(a.value), date: toDateStr(a.date) }));

  const reviewRows = await db.sql`SELECT * FROM reviews WHERE user_id = ${uid} ORDER BY review_date DESC`;
  const reviews = reviewRows.map((r) =>
    r.kind === "ai"
      ? { id: r.client_id, date: toDateStr(r.review_date), kind: "ai", wins: r.wins, weaknesses: r.weaknesses, timeAllocation: r.time_allocation, execution: r.execution, skillsSection: r.skills_section, projectsSection: r.projects_section, nextWeek: r.next_week, rating: r.rating }
      : { id: r.client_id, date: toDateStr(r.review_date), kind: "manual", wins: r.wins, challenges: r.weaknesses, nextFocus: r.next_week, rating: r.rating }
  );

  const focusSessions = await db.sql`
    SELECT client_id AS "id", mission_client_id AS "missionId", mode,
           work_minutes AS "workMinutes", result, completed_at AS "completedAt"
    FROM focus_sessions WHERE user_id = ${uid} ORDER BY completed_at DESC
  `;

  const profile = profileRow
    ? { ...profileRow, achievementsUnlocked, businessInterests: profileRow.businessInterests || [], scoreHistory: profileRow.scoreHistory || [], checkins: profileRow.checkins || [], lastActiveDate: toDateStr(profileRow.lastActiveDate) }
    : { name: "Builder", onboarded: false, xp: 0, streak: 0, achievementsUnlocked: {}, businessInterests: [], scoreHistory: [], checkins: [] };

  return { profile, skills, missions, projects, finance, assets, reviews, focusSessions };
}

async function saveState(uid, payload) {
  const client = await db.pool.connect();
  try {
    await client.query("BEGIN");

    const p = payload.profile || {};
    await client.query(
      `INSERT INTO profiles (user_id, name, age_range, role, main_goal, long_term_vision, skill_level, daily_time, existing_skills, interests, learning_style, business_interests, current_projects_text, biggest_obstacle, onboarded, xp, streak, last_active_date, missions_completed, roadmap, score_history, checkins, updated_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,NOW())
       ON CONFLICT (user_id) DO UPDATE SET
         name=$2, age_range=$3, role=$4, main_goal=$5, long_term_vision=$6, skill_level=$7,
         daily_time=$8, existing_skills=$9, interests=$10, learning_style=$11,
         business_interests=$12, current_projects_text=$13, biggest_obstacle=$14,
         onboarded=$15, xp=$16, streak=$17, last_active_date=$18, missions_completed=$19,
         roadmap=$20, score_history=$21, checkins=$22, updated_at=NOW()`,
      [uid, p.name || "Builder", p.ageRange || null, p.role || null, p.mainGoal || null,
        p.longTermVision || null, p.skillLevel || null, p.dailyTime || null,
        p.existingSkills || null, p.interests || null, p.learningStyle || null,
        JSON.stringify(p.businessInterests || []), p.currentProjectsText || null,
        p.biggestObstacle || null, !!p.onboarded, p.xp || 0, p.streak || 0,
        p.lastActiveDate || null, p.missionsCompleted || 0,
        p.roadmap ? JSON.stringify(p.roadmap) : null,
        JSON.stringify(p.scoreHistory || []), JSON.stringify(p.checkins || [])]
    );

    // Achievements are additive only — never delete unlock history.
    const unlocked = p.achievementsUnlocked || {};
    for (const key of Object.keys(unlocked)) {
      await client.query(
        `INSERT INTO achievements (user_id, achievement_key) VALUES ($1,$2) ON CONFLICT (user_id, achievement_key) DO NOTHING`,
        [uid, key]
      );
    }

    // Skills: find-or-create the catalog entry, then replace this user's progress row.
    await client.query(`DELETE FROM user_skills WHERE user_id = $1`, [uid]);
    for (const s of payload.skills || []) {
      const catalog = await client.query(
        `INSERT INTO skills (name, group_name, subcategory) VALUES ($1,$2,$3)
         ON CONFLICT (name, group_name) DO UPDATE SET subcategory = EXCLUDED.subcategory
         RETURNING id`,
        [s.name, s.group || "technology", s.subcategory || null]
      );
      await client.query(
        `INSERT INTO user_skills (user_id, skill_id, client_id, xp, prerequisites, resources, practice_tasks, linked_project_client_ids)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
         ON CONFLICT (user_id, skill_id) DO UPDATE SET
           client_id=$3, xp=$4, prerequisites=$5, resources=$6, practice_tasks=$7, linked_project_client_ids=$8`,
        [uid, catalog.rows[0].id, s.id, s.xp || 0, JSON.stringify(s.prerequisites || []),
          JSON.stringify(s.resources || []), JSON.stringify(s.practiceTasks || []),
          JSON.stringify(s.linkedProjectIds || [])]
      );
    }

    // Missions + a real completion log (so recurring missions keep history).
    await client.query(`DELETE FROM missions WHERE user_id = $1`, [uid]);
    for (const m of payload.missions || []) {
      const res = await client.query(
        `INSERT INTO missions (user_id, client_id, title, category, difficulty, estimated_minutes, recurring, skill_client_id, priority, reason, mission_date, done)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id`,
        [uid, m.id, m.title, m.category, m.difficulty, m.estimatedMinutes || 0, !!m.recurring,
          m.skillId || null, m.priority || null, m.reason || null, m.date, !!m.done]
      );
      if (m.done) {
        await client.query(
          `INSERT INTO mission_completions (mission_id, user_id, completed_date, xp_awarded)
           VALUES ($1,$2,$3,$4) ON CONFLICT (mission_id, completed_date) DO NOTHING`,
          [res.rows[0].id, uid, m.date, DIFF_XP[m.difficulty] || 10]
        );
      }
    }

    // Projects + tasks.
    await client.query(`DELETE FROM projects WHERE user_id = $1`, [uid]);
    for (const proj of payload.projects || []) {
      const res = await client.query(
        `INSERT INTO projects (user_id, client_id, name, description, problem, target_users, solution, stage, status, progress, deadline, revenue, expenses, notes, links, created_at, updated_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,NOW()) RETURNING id`,
        [uid, proj.id, proj.name, proj.description || null, proj.problem || null,
          proj.targetUsers || null, proj.solution || null, proj.stage || "Idea",
          proj.status || "Active", proj.progress || 0, proj.deadline || null,
          proj.revenue || 0, proj.expenses || 0, proj.notes || null,
          JSON.stringify(proj.links || []), proj.createdAt || new Date().toISOString().slice(0, 10)]
      );
      for (const t of proj.tasks || []) {
        await client.query(
          `INSERT INTO project_tasks (project_id, client_id, label, done) VALUES ($1,$2,$3,$4)`,
          [res.rows[0].id, t.id, t.label, !!t.done]
        );
      }
    }

    // Finance entries and assets/liabilities share one table, split by `kind`.
    await client.query(`DELETE FROM financial_records WHERE user_id = $1`, [uid]);
    for (const f of payload.finance || []) {
      await client.query(
        `INSERT INTO financial_records (user_id, client_id, kind, amount, category, note, record_date)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [uid, f.id, f.type, f.amount, f.category || null, f.note || null, f.date]
      );
    }
    for (const a of payload.assets || []) {
      await client.query(
        `INSERT INTO financial_records (user_id, client_id, kind, amount, category, note, record_date)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [uid, a.id, a.type, a.value, null, a.name || null, a.date]
      );
    }

    // Reviews (manual and AI CEO reviews share the table).
    await client.query(`DELETE FROM reviews WHERE user_id = $1`, [uid]);
    for (const r of payload.reviews || []) {
      if (r.kind === "ai") {
        await client.query(
          `INSERT INTO reviews (user_id, client_id, kind, review_date, wins, weaknesses, time_allocation, execution, skills_section, projects_section, next_week, rating)
           VALUES ($1,$2,'ai',$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
          [uid, r.id, r.date, r.wins || null, r.weaknesses || null, r.timeAllocation || null,
            r.execution || null, r.skillsSection || null, r.projectsSection || null,
            r.nextWeek || null, r.rating]
        );
      } else {
        await client.query(
          `INSERT INTO reviews (user_id, client_id, kind, review_date, wins, weaknesses, next_week, rating)
           VALUES ($1,$2,'manual',$3,$4,$5,$6,$7)`,
          [uid, r.id, r.date, r.wins || null, r.challenges || null, r.nextFocus || null, r.rating]
        );
      }
    }

    // Focus sessions.
    await client.query(`DELETE FROM focus_sessions WHERE user_id = $1`, [uid]);
    for (const fs of payload.focusSessions || []) {
      await client.query(
        `INSERT INTO focus_sessions (user_id, client_id, mission_client_id, mode, work_minutes, result, completed_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7)`,
        [uid, fs.id, fs.missionId || null, fs.mode || null, fs.workMinutes || null, fs.result || null, fs.completedAt || new Date().toISOString()]
      );
    }

    await client.query("COMMIT");
  } catch (e) {
    await client.query("ROLLBACK");
    throw e;
  } finally {
    client.release();
  }
}

exports.handler = async (event) => {
  const uid = getUserId(event);
  if (!uid) return json(401, { error: "Not authenticated." });

  try {
    if (event.httpMethod === "GET") {
      return json(200, await loadState(uid));
    }
    if (event.httpMethod === "PUT") {
      const payload = JSON.parse(event.body || "{}");
      await saveState(uid, payload);
      return json(200, { ok: true });
    }
    return json(405, { error: "Method not allowed" });
  } catch (e) {
    return json(500, { error: "Failed to sync data." });
  }
};
