// Shared session helpers for Netlify Functions.
// Session identity is a JWT stored in an HttpOnly cookie — never exposed to
// client-side JS, which is what makes it safe against XSS token theft.
const jwt = require("jsonwebtoken");

const COOKIE_NAME = "vos_session";
const MAX_AGE_SECONDS = 60 * 60 * 24 * 30; // 30 days

function secret() {
  return process.env.JWT_SECRET;
}

function signToken(userId) {
  return jwt.sign({ uid: userId }, secret(), { expiresIn: "30d" });
}

function sessionCookie(token) {
  return `${COOKIE_NAME}=${token}; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=${MAX_AGE_SECONDS}`;
}

function clearCookie() {
  return `${COOKIE_NAME}=; Path=/; HttpOnly; SameSite=Lax; Secure; Max-Age=0`;
}

function getUserId(event) {
  const headers = event.headers || {};
  const raw = headers.cookie || headers.Cookie || "";
  const parts = raw.split(";").map((p) => p.trim());
  const match = parts.find((p) => p.startsWith(COOKIE_NAME + "="));
  if (!match) return null;
  const token = match.slice(COOKIE_NAME.length + 1);
  try {
    return jwt.verify(token, secret()).uid;
  } catch (e) {
    return null;
  }
}

function json(statusCode, body, extraHeaders) {
  return {
    statusCode,
    headers: { "Content-Type": "application/json", ...(extraHeaders || {}) },
    body: JSON.stringify(body),
  };
}

module.exports = { signToken, sessionCookie, clearCookie, getUserId, json };
