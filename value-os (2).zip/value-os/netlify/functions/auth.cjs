// Handles /api/auth/signup, /login, /logout, /me, /request-password-reset,
// /reset-password (routed here via the /api/* rewrite in netlify.toml).
const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { getDatabase } = require("@netlify/database");
const { signToken, sessionCookie, clearCookie, getUserId, json } = require("./_lib/auth.cjs");

const db = getDatabase();

exports.handler = async (event) => {
  if (!process.env.JWT_SECRET) {
    return json(500, { error: "Server not configured (missing JWT_SECRET)." });
  }
  const segments = event.path.split("/").filter(Boolean);
  const action = segments[segments.length - 1];

  try {
    if (action === "signup" && event.httpMethod === "POST") {
      const { email, password, name } = JSON.parse(event.body || "{}");
      const cleanEmail = (email || "").trim().toLowerCase();
      if (!cleanEmail || !cleanEmail.includes("@")) return json(400, { error: "A valid email is required." });
      if (!password || password.length < 8) return json(400, { error: "Password must be at least 8 characters." });

      const existing = await db.sql`SELECT id FROM users WHERE email = ${cleanEmail}`;
      if (existing.length) return json(409, { error: "An account with that email already exists." });

      const hash = await bcrypt.hash(password, 10);
      const [user] = await db.sql`INSERT INTO users (email, password_hash) VALUES (${cleanEmail}, ${hash}) RETURNING id`;
      await db.sql`INSERT INTO profiles (user_id, name) VALUES (${user.id}, ${name || "Builder"})`;
      await db.sql`INSERT INTO subscriptions (user_id) VALUES (${user.id})`;

      const token = signToken(user.id);
      return json(200, { ok: true }, { "Set-Cookie": sessionCookie(token) });
    }

    if (action === "login" && event.httpMethod === "POST") {
      const { email, password } = JSON.parse(event.body || "{}");
      const cleanEmail = (email || "").trim().toLowerCase();
      const rows = await db.sql`SELECT id, password_hash FROM users WHERE email = ${cleanEmail}`;
      if (!rows.length) return json(401, { error: "Incorrect email or password." });

      const ok = await bcrypt.compare(password || "", rows[0].password_hash);
      if (!ok) return json(401, { error: "Incorrect email or password." });

      const token = signToken(rows[0].id);
      return json(200, { ok: true }, { "Set-Cookie": sessionCookie(token) });
    }

    if (action === "logout" && event.httpMethod === "POST") {
      return json(200, { ok: true }, { "Set-Cookie": clearCookie() });
    }

    if (action === "me" && event.httpMethod === "GET") {
      const uid = getUserId(event);
      if (!uid) return json(401, { authenticated: false });
      const rows = await db.sql`SELECT email FROM users WHERE id = ${uid}`;
      if (!rows.length) return json(401, { authenticated: false });
      return json(200, { authenticated: true, email: rows[0].email });
    }

    // Creates a reset token in the database. NOTE: no email service is wired
    // up yet, so the token is stored but not delivered — see README.
    if (action === "request-password-reset" && event.httpMethod === "POST") {
      const { email } = JSON.parse(event.body || "{}");
      const cleanEmail = (email || "").trim().toLowerCase();
      const rows = await db.sql`SELECT id FROM users WHERE email = ${cleanEmail}`;
      if (rows.length) {
        const token = crypto.randomBytes(24).toString("hex");
        const expiresAt = new Date(Date.now() + 60 * 60 * 1000).toISOString();
        await db.sql`INSERT INTO password_resets (user_id, token, expires_at) VALUES (${rows[0].id}, ${token}, ${expiresAt})`;
      }
      // Same response whether or not the account exists — avoids leaking who has an account.
      return json(200, { ok: true, message: "If that email exists, a reset link has been created." });
    }

    if (action === "reset-password" && event.httpMethod === "POST") {
      const { token, password } = JSON.parse(event.body || "{}");
      if (!token || !password || password.length < 8) return json(400, { error: "Invalid request." });
      const rows = await db.sql`SELECT * FROM password_resets WHERE token = ${token} AND used = FALSE AND expires_at > NOW()`;
      if (!rows.length) return json(400, { error: "This reset link is invalid or has expired." });

      const hash = await bcrypt.hash(password, 10);
      await db.sql`UPDATE users SET password_hash = ${hash} WHERE id = ${rows[0].user_id}`;
      await db.sql`UPDATE password_resets SET used = TRUE WHERE id = ${rows[0].id}`;
      return json(200, { ok: true });
    }

    return json(404, { error: "Unknown auth action." });
  } catch (e) {
    return json(500, { error: "Something went wrong. Please try again." });
  }
};
